create database if not exists ABCC_PromoterDB;
use ABCC_PromoterDB;

DROP TABLE IF EXISTS `name_dups`;
CREATE TABLE IF NOT EXISTS `name_dups` (
  `upname` varchar(30) default NULL,
  `alias` varchar(30) default NULL,
  `aliassite` varchar(50) default NULL,
  `dupname` varchar(30) default NULL,
  `dupsite` varchar(50) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `sites`;
CREATE TABLE IF NOT EXISTS `sites` (
  `name` varchar(40) default NULL,
  `site` varchar(70) default NULL,
  `factor` varchar(30) default NULL,
  `prob` float NOT NULL default '0',
  `reference` varchar(70) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `site_dups`;
CREATE TABLE IF NOT EXISTS `site_dups` (
  `site` varchar(50) default NULL,
  `namelist` varchar(250) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `tableinfo`;
CREATE TABLE IF NOT EXISTS `tableinfo` (
  `tablename` varchar(20) default NULL,
  `tabledesc` varchar(80) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

load data local infile "tfsites.dupsites" into table site_dups;
load data local infile "tfsites.sql" into table sites;
load data local infile "tfsites.dupnames" into table name_dups;

INSERT INTO `tableinfo` (`tablename`, `tabledesc`) VALUES('prom_comp', 'Promoter Composition Information');
INSERT INTO `tableinfo` (`tablename`, `tabledesc`) VALUES('prom_rmsks', 'Promoter RepeatMasker Repeats');
INSERT INTO `tableinfo` (`tablename`, `tabledesc`) VALUES('prom_strs', 'Promoter Short Tandem Repeats');
INSERT INTO `tableinfo` (`tablename`, `tabledesc`) VALUES('prom_stems', 'Promoter Inverted Repeats');
INSERT INTO `tableinfo` (`tablename`, `tabledesc`) VALUES('prom_snps', 'Promoter SNPs');
INSERT INTO `tableinfo` (`tablename`, `tabledesc`) VALUES('prom_sites', 'Promoter TF Binding Sites (Regexp)');
INSERT INTO `tableinfo` (`tablename`, `tabledesc`) VALUES('feature', 'Promoter Feature Information');
INSERT INTO `tableinfo` (`tablename`, `tabledesc`) VALUES('prom_info', 'Promoter Extraction Limits');
INSERT INTO `tableinfo` (`tablename`, `tabledesc`) VALUES('prom_rpts', 'Promoter Repeated Oligos');
INSERT INTO `tableinfo` (`tablename`, `tabledesc`) VALUES('geneinfo', 'Gene Information');


