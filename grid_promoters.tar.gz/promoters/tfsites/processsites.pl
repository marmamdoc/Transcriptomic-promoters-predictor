#!/usr/bin/perl
# ============================================================
# Parse the tfsites file from gcg and remove sites that
#  have redundant sites and also fix names to have case-
#  insensitive non-redundant names for mysql.
# Latest files downloaded from Accelerys (by Bobs)
#  (http://www.accelrys.com/bio/data_update.html)
# I am only getting the mammalian sites at this point
# ============================================================
%basecodes=("A",0.25,
            "B",0.75, #[ACG]
            "C",0.25,
            "D",0.75, #[AGT]
            "G",0.25,
            "H",0.75,  #[ACT]
            "K",0.50,  #[GT]
            "M",0.50,  #[AC]
            "N",1.0,  #[AGCT]
            "R",0.50,  #[AG]
            "S",0.50,  #[CG]
            "T",0.25,
            "U",0.25,
            "V",0.75,  #[ACG]
            "W",0.50, #[AT]
            "X",1.00, #[AGCT]
            "Y",0.50);  #[CT] 

open(IN,"tfsites-mammal.dat");

open(SQL,"> tfsites.sql");;
open(DAT,"> tfsites.dat");
open(DUPSITES,"> tfsites.dupsites");
open(DUPNAMES,">tfsites.dupnames");

%names=();
%upcasenames=();
%sites=();
%ref=();
%counts=();
%sitearray=();
%dupsarray=();

while($line=<IN>) {if($line=~/----------/) {last;}}
# go through the list, alter duplicate names to be unique...
while($line=<IN>) {
    if($line=~/^(\S+)\s+\d+\s+(\S+)\s+\d\s+\!\s+(\S+)\s+(\S[\s\S]+)\n/) {
    $name=$1;
    $site=$2;
    $factor=$3;
    $ref=$4;
}
    elsif($line=~/^(\S+)\s+\d+\s+(\S+)\s+\d\s+\!\s+(\S+)/) {
    $name=$1;
    $site=$2;
    $factor=$3;
    $ref="No Reference";
    #print "===> $line";
}

    $name=~s/^\;//;
    $name=~s/[\(\)]//g;
    $factor=~s/[\(\)]//g;
    $upname=$name;
    $upname=~tr/a-z/A-Z/;
    if($upcasenames{$upname}) {
        $count{$upname}++;
        $name2=$name;
        $name.="__".$count{$upname};
	print DUPNAMES "$upname\t$name2\t$site\t$name\t$upsites{$upname}\n";
    }
    $names{$name}=$name;
    $upcasenames{$upname}=$upname;
    $sites{$name}=$site;
    $upsites{$upname}=$site;
    $ref{$name}=$ref;
    $factors{$name}=$factor;
}
close(IN);

# now make a list of names with the same site...
foreach $item (sort keys %names) {
    if($sitearray{$sites{$item}}) {
    #print "$item $sites{$item}\n";
	if(! $duparray{$sites{$item}}) {
	    $duparray{$sites{$item}}=$sites{$item};
	}
    }
    else {
        $compsite=compSite($sites{$item});
        $prob=getProb($sites{$item});
	print DAT "$item\t$sites{$item}\n";
        if(! $factors{$item}) {$tf="??";}
        else {$tf=$factors{$item};}
	print SQL "$item\t$sites{$item}\t$tf\t";
        printf SQL "%5.3e",$prob;
        print SQL "\t$ref{$item}\n";
        print SQL "$item!\t$compsite\t$tf\t";
        printf SQL "%5.3e",$prob;
        print SQL "\t$ref{$item}\n";
    }
    $sitearray{$sites{$item}}.="$item,";
    
}

foreach $item (keys %duparray) {
    chop($sitearray{$item});
    print DUPSITES "$item\t$sitearray{$item}\n";
}
close(SQL);
close(DAT);
close(DUPNAMES);
close(DUPSITES);
exit(0);

sub compSite() {
($site)=@_;
$site=reverse($site);
@bases=split(//,$site);
$c="";
foreach $i (@bases) {
    if($i eq "A") {$c.="T";}
    if($i eq "C") {$c.="G";}
    if($i eq "G") {$c.="C";}
    if($i eq "T") {$c.="A";}    
# add the other degenerate bases...
    if($i eq "R") {$c.="Y";}
    if($i eq "Y") {$c.="R";}
    if($i eq "B") {$c.="V";}
    if($i eq "V") {$c.="B";}
    if($i eq "D") {$c.="H";}
    if($i eq "H") {$c.="D";}
    if($i eq "K") {$c.="M";}
    if($i eq "M") {$c.="K";}
    if($i eq "S") {$c.="S";}
    if($i eq "W") {$c.="W";}
    if($i eq "N") {$c.="N";}
    }
    return($c);
}

sub getProb() {
    ($site)=@_;
    @bases=split(//,$site);
    $p=1.0;
    foreach $base (@bases) {
        $p*=$basecodes{$base};
    }
    return($p);
}

