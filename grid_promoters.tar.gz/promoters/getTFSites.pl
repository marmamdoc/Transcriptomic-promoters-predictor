#!/usr/bin/perl
# =====================================================
# Script to find TFSites in an input file of sequences.
# In this form, the consensus type sites are located. 
# 120808 modified to output positions as start-stop and
# also output a file based on genomic coordinates om gff
# format. Switched to one-to-many output formats for
# both files.
# =====================================================

if (! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

$offset=-1500;

if($ARGV[0] eq "") {
    print "USAGE: getTFSites.pl <species> <FLDR> <type>\n";
    exit(1);
}
if($ARGV[2] eq "x" || $ARGV[2] eq "m") {$addon=$ARGV[2];}
else{$addon="";}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="$AnalyRootDir/$species";
$scriptdir="$ENV{ScriptHome}/computes";

# get the latest directory of updates for this species...
$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");
chdir("$outputdir/$subdir/$mydir");

open(IN,$addon."promoters.seq");
open(OUT,"> ".$addon."promoters.tfsites");
open(GEN,"> ".$addon."promoters.genomic.tfsites");

$sitefile="/bioinfoA/db_updates/ncbi_genomes/promoters/tfsites/tfsites.dat";

%basecodes=("A","A",
	    "B","[TCG]",
	    "C","C",
	    "D","[AGT]",
	    "G","G",
	    "H","[ACT]",
	    "K","[GT]",
	    "M","[AC]",
	    "N","[AGCT]",
	    "R","[AG]",
	    "S","[CG]",
	    "T","T",
	    "U","T",
	    "V","[ACG]",
	    "W","[AT]",
	    "X","[AGCT]",
	    "Y","[CT]"); 

open(SITES,$sitefile);
$c=0;
while($line=<SITES>) {
  chop($line);
  ($name[$c],$site[$c])=split(/\t/,$line);
  $site[$c]=~tr/[a-z]/[A-Z]/;
  $reg[$c]="";
  for ($i=0;$i<length($site[$c]);$i++) {$reg[$c].=$basecodes{substr($site[$c],$i,1)};}
  $compreg=$reg[$c];
  $compreg=~tr/ACGT/TGCA/;
  $creg[$c]="";
  for($o=length($compreg);$o>=0;$o--) {$creg[$c].=substr($compreg,$o,1);} 
  $creg[$c]=~tr/[]/][/;
  $c++;
}
close(SITES);
#print "read $c sites in.\n";

#print "getTFSites.pl for $ARGV[0].\n";
$count=0;
while($line=<IN>) {
    chop($line);
    if($line=~/^>(\S+)/) {
	if($seq) {
	    #print substr($seq,1,10),"\n";
	    &mapper();
	    $seq="";
	    $count++;
	    #if($count%100==0) {print "$count\n";}
	}
        $line=~/^>(\S+)/;
	$seqid=$1;
        $line=~/(chr\S+):(\d+)-(\d+)\((\S)\)/;
        $chrom=$1;
        $start=$2;
        $stop=$3;
        $strand=$4;
	#print "=== $seqid ===";
    }
    else {$seq.=$line;}
}
if($seq) {
    &mapper($seq);
    $seq="";
    $count++;
}
close(IN);
close(OUT);
close(GEN);

#print "Processed $count sequences.\n";
print "done processing tfsites\n";
$a=qx+ls -al+;
print $a;

exit 0;

sub mapper() { 
    $seq=~tr/a-z/A-Z/;
    $seq=~s/\s//g;
    $set="";
    for($n=0;$n<$c;$n++) {
	while($seq=~m/$reg[$n]/g){
            $b=pos($seq)-length($site[$n])+$offset;
            $e=pos($seq)+$offset;
	    if($strand eq "+") {
		$gb=$start+pos($seq);
		$ge=$gb+length($site[$n]);
		$st="+";
	    }
	    else{
		$gb=$stop-pos($seq)-length($site[$n]);
		$ge=$stop-pos($seq);
		$st="-";
	    }
	    print OUT "$seqid\t$name[$n]\t$b\t$e\t+\t$site[$n]\n";
	    print GEN "$chrom\tABCC\tTFBS\t$gb\t$ge\t.\t$st\t.\t";
	    print GEN "ID=$seqid\_$name[$n]\_",pos($seq),";TFOrient=plus;";
	    print GEN "TFName=$name[$n];PromPos=$b-$e\n";
	}
	while($seq=~m/$creg[$n]/g){
            $b=pos($seq)-length($site[$n])+$offset;
            $e=pos($seq)+$offset;
	    if($strand eq "+") {
		$gb=$start+pos($seq);
		$ge=$a+length($site[$n]);
		$st="-";
	    }
	    else{
		$gb=$stop-pos($seq)-length($site[$n]);
		$ge=$stop-pos($seq);
		$st="+";
	    }
	    print OUT "$seqid\t$name[$n]\t$b\t$e\t-\t$site[$n]\n";
	    print GEN "$chrom\tABCC\tTFBS\t$gb\t$ge\t.\t$st\t.\t";
	    print GEN "ID=$seqid\_$name[$n]\_",pos($seq),";TFOrient=minus;";
	    print GEN "TFName=$name[$n];PromPos=$b-$e\n";
	}
    }
    return;
}
