#!/usr/bin/perl
# ================================================================
# getPromoters.pl
# Author: Robert M. Stephens
# Convert an ncbi seq_gene.md file into gff format for gbrowse.
# Makes the following files:
#  1) promoters.gff ... gff formatted promoter file for gbrowse
#  1a) promoters.grid...grid formatted promoter file for database
#  2) promoters2genes ... gene to promoter/acc table file
#  3) promoters.seq ... fasta formatted sequence file
# 06/07 reworked it to do a better job accounting the exons etc.
#       because they arent in order in the md file.
# 01/08 converted for use for promoter extraction.
# Script to extract promoter regions for mapped genes on a genome.
# ================================================================

if ( !$ENV{ScriptHome} ) {
	$ENV{ScriptHome} = "/bioinfoA/db_updates/ncbi_genomes";
}

$offset = "$ENV{ScriptHome}/promoters/offset.pl";

if ( $ARGV[0] eq "" ) {
	print "USAGE: getPromoters.pl <species>\n";
	exit(1);
}

require("$ENV{ScriptHome}/lookups.pl");
$species = $ARGV[0];

# set up some defaults...
$dwnlddir  = "$DwnldRootDir/$species";
$outputdir = "$AnalyRootDir/$species";

# get the latest directory of updates for this species...
$mydir = "promoters";
require("$ENV{ScriptHome}/checkDir.pl");

chdir("$outputdir/$subdir/$mydir");
open( IN, "$dwnlddir/$subdir/mapview/seq_gene.md" );

print "Processing file: $dwnlddir/$subdir/mapview/seq_gene.md\n";

# read in the input file seq_gene.md  and collect records into arrays for each type
<IN>;

while ( $line = <IN> ) {
	chomp($line);
	(
		$taxon,  $chrom,       $chrstart,   $chrend,       $orient,
		$contig, $contigstart, $contigstop, $contigorient, $featname,
		$featid, $type,        $group,      $trans,        $code
	) = split( /\t/, $line );
	#print "type = $type\n";

	if ( $chrom =~ /\|/ ) { next; }    # skip chr_Un

	if ( $ref_names{ $ARGV[0] } =~ /$group/ ) 
	{
		if ( $type eq "GENE" )
		{
			push( @genelines, $line );
		}
		if ( $type eq "RNA" ) 
		{
			push( @mrnalines, $line );
		}
		if ( $type eq "PSEUDO" ) 
		{
			push( @pseudolines, $line );
		}
	}
	else 
	{
		next;
	}

}
close(IN);

# process the genes records
## note - 2 ways to have a gene dup - one has same geneid, another has
##  different geneids for the duplicates...
foreach $line (@genelines) 
{

	#print "LINE = $line\n";
#9986    1       4225959 4229511 -       NW_003159226.1  4225959 4229511 -       LOC100350216    GeneID:100350216            GENE    OryCun2.0-Primary Assembly    -       protein;identical;N
	(
		$taxon,  $chrom,       $chrstart,   $chrend,       $orient,
		$contig, $contigstart, $contigstop, $contigorient, $featname,
		$featid, $type,        $group,      $trans,        $code
	) = split( /\t/, $line );
	$featid =~ /(\d+)/;    #GeneID:100350216
	$geneid = "$1";
	$featname =~ s/\@/_at/g;

# label duplicate genes accordingly...
#9986    1       192351229       192351301       -       NW_003159230.1  34719272        34719344        -       TRNAV-     UAC       GeneID:100380221      GENE    OryCun2.0-Primary Assembly      -       tRNAscan-SE;external;N
#9986    1       192351508       192351580       -       NW_003159230.1  34719551        34719623        -       TRNAV-U    AC       GeneID:100380221      GENE    OryCun2.0-Primary Assembly      -       tRNAscan-SE;external;N

	#print "genecounts/featname = $genecounts{$featname}\n";<STDIN>;
	if ( $genecounts{$featname} ) 
	{
		$genename = $featname . "__" . ( $genecounts{$featname} + 1 );
		if   ( $geneid == $geneids{$featname} ) 
		{ 
			$type = "same"; 
		}
		else                                    
		{ 
			$type = "diff"; 
		}
		print "Saw $featname as gene again...($genename) $geneid/$geneids{$featname} ($type)\n";

		#Saw TRNAV-UAC as gene again...(TRNAV-UAC__2) 100380221/100380221 (same)
	}
	else 
	{ 
		$genename = $featname; 
	}
	$genetypes{$genename}   = $type;
	$genestarts{$genename}  = $chrstart;
	$genestops{$genename}   = $chrend;
	$genechroms{$genename}  = "chr$chrom";
	$geneorients{$genename} = $orient;
	$geneids{$genename}     = $geneid;
	$genenames[$geneid]     = $genename;
	$genecounts{$genename}++;
	if ( $featname ne $genename ) 
	{ 
		$genecounts{$featname}++; 
	}

	
}

# next, process the mrnas
foreach $line (@mrnalines) 
{
	(
		$taxon,  $chr,         $chrstart,   $chrend,       $orient,
		$contig, $contigstart, $contigstop, $contigorient, $featname,
		$featid, $type,        $group,      $trans,        $code
	) = split( /\t/, $line );

#9986    1       126038  175183  +       NW_003159226.1  126038  175183  +       XM_002708115.1          RNA     OryCun2    .0-Primary Assembly   XM_002708115.1   mRNA;identical;N

	$featid =~ /(\d+)/;
	$geneid = "$1";
	$featname =~ s/\@/_at/g;
	$chrom = "chr$chr";

	# remove orphan mrnas...
	if ( !$genenames[$geneid] ) 
	{
		print "Apparent orphan mRNA $featname\n";
		next;
	}

	# determine which gene locus this mrna belongs to...
	$cluster = "";
	if ( $genenames[$geneid] =~ /(\S+)__2/ ) 
	{

		#print "$genetypes{$genenames[$geneid]} $1 $chrom $genechroms{$genenames[$geneid]} ";
		#print "$genestarts{$genenames[$geneid]} $chrstart $chrend ";
		#print "$genestops{$genenames[$geneid]} $geneid  $geneids{$1}\n";
	}

	if ( $genetypes{ $genenames[$geneid] } eq "same" ) 
	{
		$genenames[$geneid] =~ /(\S+)\__/;
		$g = $1;

		print "$g ===> $genecounts{$g}\n";
	}
	else 
	{ 
		$g = $genenames[$geneid]; 
	}
	if (   $chrom eq $genechroms{$g} && $chrstart >= $genestarts{$g} && $chrend <= $genestops{$g} )
	{
		$cluster = $g;
	}
	else 
	{
		for ( $m = 1 ; $m < $genecounts{$g} ; $m++ ) 
		{
			$tmp = $g . "__" . ( $m + 1 );
			print "$tmp\n";
			if (   $chrom eq $genechroms{$tmp} && $chrstart >= $genestarts{$tmp} && $chrend <= $genestops{$tmp} )
			{
				$cluster = $tmp;
				$last;
			}
		}
	}

	# skip mrnas not in any gene cluster...
	if ( !$cluster ) 
	{
		print "Not in cluster mRNA $featname (orphan) $geneid $genenames[$geneid] $genecounts{$genenames[$geneid]}\n";
		next;
	}

#else{print "assigned mrna $featname to $cluster ($chrom $chrstart $chrend $genechroms{$cluster} $genestarts{$cluster} $genestops{$cluster})\n";}
# now see if we have seen this mrna before...
	if ( $mrnacounts{$featname} ) 
	{
		$mrnaname = $featname . "__" . ( $mrnacounts{$featname} + 1 );
		print "Saw $featname as mrna again...($mrnaname)\n";
	}
	else 
	{ 
		$mrnaname = $featname; 
	}
	$mrnastarts{$mrnaname}  = $chrstart;
	$mrnastops{$mrnaname}   = $chrend;
	$mrnachroms{$mrnaname}  = $chrom;
	$mrnaorients{$mrnaname} = $orient;
	$mrnageneids{$mrnaname} = $geneid;
	$mrnacounts{$featname}++;
	$mrnaaccs{$cluster} .= "$mrnaname,";

}

# next, process the pseudos...
foreach $line (@pseudolines) 
{
	(
		$taxon,  $chr,         $chrstart,   $chrend,       $orient,
		$contig, $contigstart, $contigstop, $contigorient, $featname,
		$featid, $type,        $group,      $trans,        $code
	) = split( /\t/, $line );
	$featid =~ /(\d+)/;
	$geneid = "$1";
	$featname =~ s/\@/_at/g;
	$chrom = "chr$chr";

	# remove orphan pseudos...
	if ( !$genenames[$geneid] ) 
	{
		print "Apparent orphan pseudo $featname (gene)\n";
		next;
	}

	# determine which gene locus this pseudo belongs to...
	$cluster = "";
	if ( $genenames[$geneid] =~ /(\S+)__2/ ) 
	{
		#print "$genetypes{$genenames[$geneid]} $1 $chrom $genechroms{$genenames[$geneid]} ";
		#print "$genestarts{$genenames[$geneid]} $chrstart $chrend ";
		#print "$genestops{$genenames[$geneid]} $geneid  $geneids{$1}\n";
	}
	if ( $genetypes{ $genenames[$geneid] } eq "same" ) 
	{
		$genenames[$geneid] =~ /(\S+)\__/;
		$g = $1;
	}
	else { $g = $genenames[$geneid]; }
	if (   $chrom eq $genechroms{$g} && $chrstart >= $genestarts{$g} && $chrend <= $genestops{$g} )
	{
		$cluster = $g;
	}
	else 
	{
		for ( $m = 1 ; $m < $genecounts{$g} ; $m++ ) 
		{
			$tmp = $g . "__" . ( $m + 1 );
			if (   $chrom eq $genechroms{$tmp} && $chrstart >= $genestarts{$tmp} && $chrend <= $genestops{$tmp} )
			{
				$cluster = $tmp;
				$last;
			}
		}
	}

	# skip pseudos not in any gene cluster...
	if ( !$cluster ) 
	{
		print "$geneid $genenames[$geneid] $genecounts{$genenames[$geneid]} $trans $mrnacounts{$trans}\n";
		print "Not in cluster pseudo $featname (orphan)\n";
		next;
	}

#else{print "assigned pseudo $featname to $cluster ($chrom $chrstart $chrend $genechroms{$cluster} $genestarts{$cluster}    $genestops{$cluster})\n";}
	$pseudos{$cluster} = "Pseudo";
}

# print out the genes/mrnas and exons (no orphan mrnas or exons allowed)...
open( GFF, "> promoters.gff" );
print GFF "##gff-version 3\n";
open( SQL,  "> promoters2gene" );
open( SEQ,  "> promoters.seq" );
open( GRID, "> promoters.grid" );

foreach $gene ( keys %genestarts ) 
{
	if ( $pseudos{$gene} ) { next; }
	chop( $mrnaaccs{$gene} );

	#print "gene = $gene: mrnaAccs = $mrnaaccs{$gene}\n";
	@ms = split( /,/, $mrnaaccs{$gene} );

	foreach $mrna (@ms) 
	{
		$mrna =~ /(\S+)\./;
		$accn = $1;
		if ( $mrnaorients{$mrna} eq "+" ) 
		{
			$pstart = $mrnastarts{$mrna} - 1499;
			$pstop  = $mrnastarts{$mrna} + 200;
		}
		else 
		{
			$pstart = $mrnastops{$mrna} - 200;
			$pstop  = $mrnastops{$mrna} + 1499;
		}

		# see if this is the second hit for this gene...
		if ( $promoters{$gene}[0] ) 
		{
			$found = 0;

			#print "Already had promoter(s) for $gene\n";
			for ( $d = 0 ; $d <= $promotercount{$gene} ; $d++ ) 
			{

#print "$d\t$mrna\t$promoters{$gene}[$d]\t$mrnachroms{$mrna}:$pstart-$pstop($mrnaorients{$mrna})\n";
				if ( $promoters{$gene}[$d] eq "$mrnachroms{$mrna}:$pstart-$pstop($mrnaorients{$mrna})" )
				{
					$found = 1;
				}
			}
			if ($found) { next; }
			$promotercount{$gene}++;
			$promoters{$gene}[ $promotercount{$gene} ] = "$mrnachroms{$mrna}:$pstart-$pstop($mrnaorients{$mrna})";
			print GFF "$mrnachroms{$mrna}\tABCC\tPromoter\t$pstart\t$pstop\t.\t$mrnaorients{$mrna}\t.\t";
			print GFF "ID=$gene\_Prm$promotercount{$gene};Gene=$gene;";
			print GFF "GeneID=$geneids{$gene};RefseqAcc=$accn";
			print GFF ";Tag=MultiplePromoters";
			print GFF "\n";
			print GRID "$gene\_Prm$promotercount{$gene}\t$mrnachroms{$mrna}\tPromoter\tPromoter\t1\t";
			print GRID $pstop - $pstart + 1, "\t$mrnaorients{$mrna}\t$pstart\t$pstop\t$accn;Multi\n";
			
			print "GFF = $mrnachroms{$mrna}\tABCC\tPromoter\t$pstart\t$pstop\t.\t$mrnaorients{$mrna}\t.\t";
			print "ID=$gene\_Prm$promotercount{$gene};Gene=$gene;";
			print "GeneID=$geneids{$gene};RefseqAcc=$accn";
			print ";Tag=MultiplePromoters";
			print "\n";
			print "GRID = $gene\_Prm$promotercount{$gene}\t$mrnachroms{$mrna}\tPromoter\tPromoter\t1\t";
			print $pstop - $pstart + 1, "\t$mrnaorients{$mrna}\t$pstart\t$pstop\t$accn;Multi\n"; 
			getSeq();
		}
		else 
		{
			$promotercount{$gene} = 0;
			$promoters{$gene}[ $promotercount{$gene} ] = "$mrnachroms{$mrna}:$pstart-$pstop($mrnaorients{$mrna})";

			#print "$gene\t$mrna\t$promoters{$gene}[$promotercount{$gene}]\n";
			print GFF "$mrnachroms{$mrna}\tABCC\tPromoter\t$pstart\t$pstop\t.\t$mrnaorients{$mrna}\t.\t";
			print GFF "ID=$gene\_Prm0;Gene=$gene;GeneID=$geneids{$gene};RefseqAcc=$accn";
			print GFF "\n";
			print GRID "$gene\_Prm0\t$mrnachroms{$mrna}\tPromoter\tPromoter\t1\t";
			print GRID $pstop - $pstart + 1, "\t$mrnaorients{$mrna}\t$pstart\t$pstop\t$accn;Single\n";
			
			print "GFF = $mrnachroms{$mrna}\tABCC\tPromoter\t$pstart\t$pstop\t.\t$mrnaorients{$mrna}\t.\t";
			print "ID=$gene\_Prm0;Gene=$gene;GeneID=$geneids{$gene};RefseqAcc=$accn";
			print "\n";
			print "GRID = $gene\_Prm0\t$mrnachroms{$mrna}\tPromoter\tPromoter\t1\t";
			print $pstop - $pstart + 1, "\t$mrnaorients{$mrna}\t$pstart\t$pstop\t$accn;Single\n";
			getSeq();
		}
		print SQL "$gene\t$gene\_Prm$promotercount{$gene}\t$geneids{$gene}\t$mrna\t$mrnachroms{$mrna}";
		print SQL "\t$pstart\t$pstop\t$mrnaorients{$mrna}\n";
		print "SQL = $gene\t$gene\_Prm$promotercount{$gene}\t$geneids{$gene}\t$mrna\t$mrnachroms{$mrna}";
		print "\t$pstart\t$pstop\t$mrnaorients{$mrna}\n";<STDIN>;
	}
}
close(IN);
close(GFF);
close(SQL);
close(SEQ);
close(GRID);

$a = qx+$offset promoters.seq > promoters.offset+;
print "done mapping promoters\n";
$a = qx+ls -al+;
print $a;

exit(0);

# ------------------------------------------------------------------------
# promoters.seq
#-------------------------------------------------------------------------
sub getSeq() 
{
	$file = "$dwnlddir/$subdir/chromosomes/$chrom_prefixes{$species}$mrnachroms{$mrna}$chrom_suffixes{$species}";

#/bioinfoA/dwnld/ncbi_genomes/human/20090918/chromosomes/hs_ref_GRCh37_chr7.fa.fix

	if ( !$promotercount{$gene} ) { $promotercount{$gene} = 0; }
	$cmd = "/bioinfoA/apps/perl/fetch2.pl $file $pstart $pstop $mrnaorients{$mrna}| grep -v '>'";

	#print "$cmd\n";
	$a = qx+$cmd+;
	print SEQ ">$gene\_Prm$promotercount{$gene} $mrnachroms{$mrna}:$pstart-$pstop($mrnaorients{$mrna}) GeneID:$geneids{$gene} Refseq:$mrna\n";
	print SEQ $a;
	return;
}
