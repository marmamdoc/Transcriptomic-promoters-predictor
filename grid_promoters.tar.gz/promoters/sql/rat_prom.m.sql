# ratmPromoter Database Loader Script
create database if not exists GFF_Rat_3_GRID;
use GFF_Rat_3_GRID;
drop table if exists mprom_sites;
create table if not exists mprom_sites (
`promoter` varchar(25) default NULL,
`sitename` varchar(40) default NULL,
`start` integer default NULL,
`stop` integer default NULL,
`strand` varchar(1) default NULL,
`site` varchar(25) default NULL,
KEY `promoter` (`promoter`),
KEY `sitename` (`sitename`),
KEY `start` (`start`),
KEY `stop` (`stop`));
drop table if exists mprom2gene;
CREATE TABLE if not exists mprom2gene (
`genename` varchar(20) default NULL,
`promoter` varchar(25) default NULL,
`geneid` integer,
`mrnaacc` varchar(15) default NULL, 
`chrom` varchar(12) default NULL,
`start` integer default NULL,
`stop` integer,
`strand` char,
KEY `promoter` (`promoter`),
KEY `chrom` (`chrom`),
KEY `start` (`start`),
KEY `stop` (`stop`)
);
drop table if exists mprom_strs;
CREATE TABLE if not exists mprom_strs (
`promoter` varchar(25) default NULL,
`start` integer default NULL,
`stop` integer,
`rpt` varchar(16),
`nbr` integer,
`seq` varchar(255),
KEY `promoter` (`promoter`),
KEY `start` (`start`),
KEY `stop` (`stop`)
);
drop table if exists mprom_rpts;
CREATE TABLE if not exists mprom_rpts (
`promoter` varchar(25) default NULL,
`start` integer default NULL,
`rpt` varchar(100),
`postn` varchar(255),
KEY `promoter` (`promoter`),
KEY `start` (`start`)
);
drop table if exists mprom_comp;
CREATE TABLE if not exists mprom_comp(
`promoter` varchar(25) default NULL,
`cnta` int default 0,
`cntc` int default 0,
`cntg` int default 0,
`cntt` int default 0,
`cntn` int default 0,
`fraca` double default 0.0,
`fracc` double default 0.0,
`fracg` double default 0.0,
`fract` double default 0.0,
`fracn` double default 0.0,
`fracac` double default 0.0,
`fracag` double default 0.0,
`fracat` double default 0.0);
drop table if exists mprom_genscan;
CREATE TABLE if not exists mprom_genscan(
`promoter` varchar(25) default null,
`result` varchar(80) default null);
drop table if exists mprom_stems;
CREATE TABLE if not exists mprom_stems(
`promoter` varchar(25),
`status` varchar(15),
`len` integer,
`begin1` integer,
`end1` integer,
`seq1` varchar(50),
`begin2` integer,
`end2` integer,
`seq2` varchar(50));
drop table if exists mprom_snps;
CREATE TABLE if not exists mprom_snps(
`promoter` varchar(25) default null,
`snpid` varchar(12) default null,
`pos` int default 0);
drop table if exists mprom_rmsks;
CREATE TABLE if not exists mprom_rmsks(
`promoter` varchar(25) default null,
`rmskname` varchar(20) default null,
`start` int default 0,
`stop` int default 0);
drop table if exists mprom_tfprfs;
create table if not exists mprom_tfprfs(
`promoter` varchar(25) default null,
`profile` varchar(15) default null,
`start` int default 0,
`stop` int default 0,
`strand` char(1),
`site` varchar(25) default null,
`prob1` float default 0,
`prob2` float default 0,
KEY `promoter` (`promoter`),
KEY `profile` (`profile`),
KEY `start` (`start`),
KEY `stop` (`stop`));
drop table if exists mprom_info;
CREATE TABLE if not exists mprom_info (
  `name` varchar(45) default NULL,
  `chrom` varchar(12) default NULL,
  `category` varchar(20) default NULL,
  `type` varchar(99) default NULL,
  `nbr` int(11) default NULL,
  `len` int(11) default NULL,
  `strand` char(1) default NULL,
  `start` int(11) default NULL,
  `stop` int(11) default NULL,
  `info` varchar(30) NOT NULL,
  KEY `name` (`name`),
  KEY `chrom` (`chrom`),
  KEY `start` (`start`),
  KEY `stop` (`stop`),
  KEY `category` (`category`),
  KEY `type` (`type`),
  KEY `nbr` (`nbr`),
  KEY `len` (`len`)
);
drop table if exists mprom_retrieval_info;
CREATE TABLE if not exists mprom_retrieval_info (
 `file` varchar(30) NOT NULL,
  `traceid` varchar(20) NOT NULL,
  `offset` int(11) NOT NULL,
  `bytes` int(11) NOT NULL
);
load data local infile "/bioinfoB/ncbi_genomes/rat/20080409/promoters/mpromoters2gene" into table mprom2gene;
load data local infile "/bioinfoB/ncbi_genomes/rat/20080409/promoters/mpromoters.strs" into table mprom_strs;
load data local infile "/bioinfoB/ncbi_genomes/rat/20080409/promoters/mpromoters.rpts" into table mprom_rpts;
load data local infile "/bioinfoB/ncbi_genomes/rat/20080409/promoters/mpromoters.comp" into table mprom_comp;
load data local infile "/bioinfoB/ncbi_genomes/rat/20080409/promoters/mpromoters.genscan" into table mprom_genscan;
load data local infile "/bioinfoB/ncbi_genomes/rat/20080409/promoters/mpromoters.stems" into table mprom_stems;
load data local infile "/bioinfoB/ncbi_genomes/rat/20080409/promoters/mpromoters.grid" into table mprom_info;
load data local infile "/bioinfoB/ncbi_genomes/rat/20080409/promoters/mpromoters.offset" into table mprom_retrieval_info;
load data local infile "/bioinfoB/ncbi_genomes/rat/20080409/promoters/mpromoters.tfsites" into table mprom_sites;
load data local infile "/bioinfoB/ncbi_genomes/rat/20080409/promoters/mpromoters.tfprfs.parse" into table mprom_tfprfs;

exit
