# GFF_Human_37_GRIDGRID SNP Database Loader Script
create database if not exists GFF_Human_37_Grid_test;
use GFF_Human_37_Grid_test;
drop table if exists I_SnpImpacts;
create table if not exists I_SnpImpacts (
`snpid` varchar(12) default NULL,
`gene` varchar(12) default NULL,
`mrna` varchar(12) default NULL,
`protein` varchar(12) default NULL,
`impact` varchar(25) default NULL,
`frame` tinyint default NULL,
`aapos` mediumint,
`allele` varchar(5),
`residue` char(1));
drop table if exists I_Snps;
CREATE TABLE if not exists I_Snps (
`snpid` varchar(12) default NULL,
`chrom` varchar(5) default NULL,
`position` integer,
`alleles` varchar(20) default NULL, 
`het` float default NULL,
`stderr` float default NULL);
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch10.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch15.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch1.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chUn.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch14.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chNotOn.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch12.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch21.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch13.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch3.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chPAR.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch19.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch17.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chX.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch2.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch11.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch18.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch12.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch14.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch22.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chMT.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chAltOnly.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch17.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch20.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch19.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch2.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch5.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch16.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chUn.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chMT.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch8.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch18.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch9.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch4.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch4.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch6.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch7.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chMulti.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch21.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch22.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch11.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch15.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chX.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch10.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chAltOnly.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch16.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch9.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch20.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch5.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chMulti.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch7.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chY.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chNotOn.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch3.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch8.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch6.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chPAR.flat.snpinfo" into table I_Snps;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_chY.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch13.flat.geneimpacts" into table I_SnpImpacts;
load data local infile "/bioinfoB/dwnld/dbsnp/human/ds_flat_ch1.flat.geneimpacts" into table I_SnpImpacts;
