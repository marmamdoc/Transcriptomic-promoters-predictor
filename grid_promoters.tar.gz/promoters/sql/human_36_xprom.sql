# humanxPromoter Database Loader Script
create database if not exists GFF_Human_36_Grid_test;
use GFF_Human_36_Grid_test;

drop table if exists xprom_tfprfs;

create table if not exists xprom_tfprfs(
`promoter` varchar(25) default null,
`profile` varchar(15) default null,
`start` int default 0,
`stop` int default 0,
`strand` char(1),
`site` varchar(25) default null,
`prob1` float default 0,
`prob2` float default 0,
KEY `promoter` (`promoter`),
KEY `profile` (`profile`),
KEY `start` (`start`),
KEY `stop` (`stop`));


load data local infile "/bioinfoB/ncbi_genomes/human/20070709/promoters/xpromoters.tfprfs.parse" into table xprom_tfprfs;

exit
