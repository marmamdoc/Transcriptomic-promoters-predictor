# human xPromoter Database Loader Script
create database if not exists GFF_Human_37_GRID;
use GFF_Human_37_GRID;
drop table if exists xprom_sites;
create table if not exists xprom_sites (
`promoter` varchar(25) default NULL,
`sitename` varchar(40) default NULL,
`start` integer default NULL,
`stop` integer default NULL,
`strand` varchar(1) default NULL,
`site` varchar(25) default NULL,
KEY `promoter` (`promoter`),
KEY `sitename` (`sitename`),
KEY `start` (`start`),
KEY `stop` (`stop`));
drop table if exists xprom2gene;
CREATE TABLE if not exists xprom2gene (
`genename` varchar(20) default NULL,
`promoter` varchar(25) default NULL,
`geneid` integer,
`mrnaacc` varchar(15) default NULL, 
`chrom` varchar(12) default NULL,
`start` integer default NULL,
`stop` integer,
`strand` char,
KEY `promoter` (`promoter`),
KEY `chrom` (`chrom`),
KEY `start` (`start`),
KEY `stop` (`stop`)
);
drop table if exists xprom_strs;
CREATE TABLE if not exists xprom_strs (
`promoter` varchar(25) default NULL,
`start` integer default NULL,
`stop` integer,
`rpt` varchar(16),
`nbr` integer,
`seq` varchar(255),
KEY `promoter` (`promoter`),
KEY `start` (`start`),
KEY `stop` (`stop`)
);
drop table if exists xprom_rpts;
CREATE TABLE if not exists xprom_rpts (
`promoter` varchar(25) default NULL,
`start` integer default NULL,
`rpt` varchar(100),
`postn` varchar(255),
KEY `promoter` (`promoter`),
KEY `start` (`start`)
);
drop table if exists xprom_comp;
CREATE TABLE if not exists xprom_comp(
`promoter` varchar(25) default NULL,
`cnta` int default 0,
`cntc` int default 0,
`cntg` int default 0,
`cntt` int default 0,
`cntn` int default 0,
`fraca` double default 0.0,
`fracc` double default 0.0,
`fracg` double default 0.0,
`fract` double default 0.0,
`fracn` double default 0.0,
`fracac` double default 0.0,
`fracag` double default 0.0,
`fracat` double default 0.0);
drop table if exists xprom_genscan;
CREATE TABLE if not exists xprom_genscan(
`promoter` varchar(25) default null,
`result` varchar(80) default null);
drop table if exists xprom_stems;
CREATE TABLE if not exists xprom_stems(
`promoter` varchar(25),
`status` varchar(15),
`len` integer,
`begin1` integer,
`end1` integer,
`seq1` varchar(50),
`begin2` integer,
`end2` integer,
`seq2` varchar(50));
drop table if exists xprom_snps;
CREATE TABLE if not exists xprom_snps(
`promoter` varchar(25) default null,
`snpid` varchar(12) default null,
`pos` int default 0);
drop table if exists xprom_rmsks;
CREATE TABLE if not exists xprom_rmsks(
`promoter` varchar(25) default null,
`rmskname` varchar(20) default null,
`start` int default 0,
`stop` int default 0);
drop table if exists xprom_tfprfs;
create table if not exists xprom_tfprfs(
`promoter` varchar(25) default null,
`profile` varchar(15) default null,
`start` int default 0,
`stop` int default 0,
`strand` char(1),
`site` varchar(25) default null,
`prob1` float default 0,
`prob2` float default 0,
KEY `promoter` (`promoter`),
KEY `profile` (`profile`),
KEY `start` (`start`),
KEY `stop` (`stop`));
drop table if exists xprom_info;
CREATE TABLE if not exists xprom_info (
  `name` varchar(45) default NULL,
  `chrom` varchar(12) default NULL,
  `category` varchar(20) default NULL,
  `type` varchar(99) default NULL,
  `nbr` int(11) default NULL,
  `len` int(11) default NULL,
  `strand` char(1) default NULL,
  `start` int(11) default NULL,
  `stop` int(11) default NULL,
  `info` varchar(30) NOT NULL,
  KEY `name` (`name`),
  KEY `chrom` (`chrom`),
  KEY `start` (`start`),
  KEY `stop` (`stop`),
  KEY `category` (`category`),
  KEY `type` (`type`),
  KEY `nbr` (`nbr`),
  KEY `len` (`len`)
);
drop table if exists xprom_retrieval_info;
CREATE TABLE if not exists xprom_retrieval_info (
 `file` varchar(30) NOT NULL,
  `traceid` varchar(20) NOT NULL,
  `offset` int(11) NOT NULL,
  `bytes` int(11) NOT NULL
);
load data local infile "/bioinfoB/ncbi_genomes/human/20090918/promoters/xpromoters2gene" into table xprom2gene;
load data local infile "/bioinfoB/ncbi_genomes/human/20090918/promoters/xpromoters.strs" into table xprom_strs;
load data local infile "/bioinfoB/ncbi_genomes/human/20090918/promoters/xpromoters.rpts" into table xprom_rpts;
load data local infile "/bioinfoB/ncbi_genomes/human/20090918/promoters/xpromoters.comp" into table xprom_comp;
load data local infile "/bioinfoB/ncbi_genomes/human/20090918/promoters/xpromoters.genscan" into table xprom_genscan;
load data local infile "/bioinfoB/ncbi_genomes/human/20090918/promoters/xpromoters.stems" into table xprom_stems;
load data local infile "/bioinfoB/ncbi_genomes/human/20090918/promoters/xpromoters.grid" into table xprom_info;
load data local infile "/bioinfoB/ncbi_genomes/human/20090918/promoters/xpromoters.offset" into table xprom_retrieval_info;
load data local infile "/bioinfoB/ncbi_genomes/human/20090918/promoters/xpromoters.tfsites" into table xprom_sites;
load data local infile "/bioinfoB/ncbi_genomes/human/20090918/promoters/xpromoters.tfprfs.parse" into table xprom_tfprfs;

exit
