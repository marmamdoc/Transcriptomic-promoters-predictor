#!/usr/local/bin/perl
# ================================================================
# Script to extract promoter regions for mapped genes on a genome.
# Makes the following files:
#  1) promoters.gff ... gff formatted promoter file for gbrowse
#  1a) promoters.grid...grid formatted promoter file for database
#  2) gene2promoters ... gene to promoter/acc table file
#  3) promoters.seq ... fasta formatted sequence file
# ================================================================

$dataarea="/abcc/tmp/ncbi_genomes";
$workdir="$dataarea/$ARGV[0]/mapview";
$outdir="$dataarea/$ARGV[0]/parsed";
$seqdir="$dataarea/$ARGV[0]/chromosomes";

%dirs=("human","hs_ref","mouse","mm_ref","chimp","ptr_ref","dog","cfa",
        "chicken","gga","rat","rn_ref","macaque","mmu_ref","cow","bt",
       "bee","ame_ref");
%refs=("human","reference","mouse","C57BL/6J","dog","Dog2.0",
        "rat","RGSC_v3.4","chimp","Pan_troglodytes-2.1","cow","Btau_2.0",
        "macaque","Mmul_051212","chicken","WUGSC","bee","Amel_4.0");

if ($ARGV[0] eq "") {
    print "USAGE: getPromoters.pl <species>\n";
    exit(1);
}

open(IN,"$workdir/seq_gene.md");
open(GFF,"> $outdir/promoters.gff");
open(SQL,"> $outdir/gene2promoters");
open(SEQ,"> $outdir/promoters.seq");
open(GRID,"> $outdir/promoters.grid");

print GFF "##gff-version 3\n";
while($line=<IN>) {
    chomp($line);
    ($taxon,$chrom,$chbegin,$chend,$chstrand,$contig,$cobegin,$coend,$costrand,
     $accn,$gene,$type,$genome,$group,$evidence)=split(/\t/,$line);
    if($genome ne $refs{$ARGV[0]}) {next;}
    if($chrom=~/\|/) {next;}
    $gene=~/(\d+)/;
    $geneid=$1;
    $accn=~/(\S+)\./;
    $acc=$1;
    #print "$geneid $accn\n";
    if ($type eq "GENE") {
	$genename=$accn;
	$gene_geneid=$geneid;
    }
    elsif($type eq "RNA") {
	if($geneid != $gene_geneid) {next;}
	if($chstrand eq "+") {
	    $pstart=$chbegin-1499;
	    $pstop=$chbegin+200;
	}
	else {
	    $pstart=$chend-200;
	    $pstop=$chend+1499;
	}

# see if this is the second hit for this gene...
	if($promoters[$geneid]) {
	    if($promoters[$geneid] ne "$chrom:$pstart-$pstop($chstrand)") {
		$promotercount[$geneid]++;
		print GFF "chr$chrom\tABCC\tPromoter\t$pstart\t$pstop\t.\t$chstrand\t.\t";
		print GFF "ID=Promoter:$genename\_Prm$promotercount[$geneid];Gene=$genename;GeneID=$geneid;RefseqAcc=$acc";
		print GFF ";Tag=MultiplePromoters";
		print GFF "\n";
                print GRID "$genename\_Prm$promotercount[$geneid]\tchr$chrom\t\tPromoter\tPromoter\t1\t",$pstop-$pstart+1,"\t$chstrand\t$pstart\t$pstop\t$acc;Multi\n";
		getSeq();
	    }
	    #else {print "had $geneid $genename $accn\n";}
	}
	else {
	    print GFF "chr$chrom\tABCC\tPromoter\t$pstart\t$pstop\t.\t$chstrand\t.\t";
	    print GFF "ID=Promoter:$genename\_Prm0;Gene=$genename;GeneID=$geneid;RefseqAcc=$acc";
	    print GFF "\n";
                print GRID "$genename\_Prm0\tchr$chrom\tPromoter\tPromoter\t1\t",$pstop-$pstart+1,"\t$chstrand\t$pstart\t$pstop\t$acc;Single\n";
	    getSeq();
	}
	print SQL "$genename\t$genename\_Prm$promotercount[$geneid]\t$geneid\t$acc\t$chrom\t$pstart\t$pstop\t$chstrand\n";
	$promoters[$geneid]="$chrom:$pstart-$pstop($chstrand)";
    }
}
close(IN);
close(GFF);
close(SQL);
close(SEQ);
close(GRID);
exit(0);

sub getSeq() {
    if(! $promotercount[$geneid]) {$promotercount[$geneid]=0;}
    $cmd="/abcc/apps/perl/fetch2.pl $seqdir/$dirs{$ARGV[0]}\_chr$chrom.fa $pstart $pstop $chstrand| tail +2";
    $a=qx+$cmd+;
    print SEQ ">$genename\_Prm$promotercount[$geneid] chr$chrom:$pstart-$pstop($chstrand) GeneID:$geneid Refseq:$acc\n";
    print SEQ $a;
    return;
}


