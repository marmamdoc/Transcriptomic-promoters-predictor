#!/usr/bin/perl
# ==============================================================
# Script to find palindromes within an input file of sequence
#  regions.
# ==============================================================

if(! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

if($ARGV[0] eq "") {
    print "USAGE: getStems.pl <species> <fldr> <type ( |m|x)>\n";
    exit(1);
}
if($ARGV[2] eq "x" || $ARGV[2] eq "m") {$addon=$ARGV[2];}
else{$addon="";}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="$AnalyRootDir/$species";

# get the latest directory of updates for this species...
$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");
chdir("$outputdir/$subdir/$mydir");

open(IN,$addon."promoters.seq");
open(OUT,"> ".$addon."promoters.stems");

while($line=<IN>) {
    if($line=~/^>(\S+)/) {
	if($seq) {&processSeq();}
        $seq="";
        $acc=$1;
    }
    else {$seq.=$line;}
}
close(IN);
if($seq) {&processSeq();}
close(OUT);
print "done with stems\n";
$a=qx+ls -al+;
print $a;

exit(0);

sub processSeq() {
    if($seq=~/NNNN/) {print OUT "$acc\tHas Ns\n";return;}
    open(T,"> $addon"."stestseq");
    print T ">$acc\n$seq";
    close(T);
    $cmd="palindrome $addon"."stestseq -auto -nooverlap -stdout 2>/dev/null";
    #print "$cmd\n";
    $a=qx+$cmd+;
    $start=index($a,"Palindromes:");
    $b=substr($a,$start+1);
    if(length($b)<20) {print OUT "$acc\tNone Found\n";}
    else {
	#print "$acc ok\n";
	@rows=split(/\n/,$b);
	for($i=1;$i<=$#rows;$i+=4) {
#            print "$rows[$i]\n$rows[$i+2]\n";
	    $rows[$i]=~/(\d+)\s+(\S+)\s+(\d+)/;
	    $b1=$1-1500;$s1=$2;$e1=$3-1500;
	    $rows[$i+2]=~/(\d+)\s+(\S+)\s+(\d+)/;
	    $b2=$3-1500;$s2=$2;$e2=$1-1500;
	    if(length($s1)>100) {
		$s=substr($s1,0,100);
		$t=substr($s2,0,100);
	    }
	    else {
		$s=$s1;
		$t=$s2;
	    }
	    print OUT "$acc\tOK\t",length($s1),"\t$b1\t$e1\t$s\t$b2\t$e2\t$t\n";
	}
    }   
    return;
}

