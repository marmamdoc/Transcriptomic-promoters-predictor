#!/usr/bin/perl

open(IN,$ARGV[0]);
$fcount=1;
$count=0;
open(OUT,">$ARGV[0]\_$fcount");
while($line=<IN>) {
    if($line=~/^>/) {
	$count++;
	if($count % 100 == 0) {
	    close(OUT);
	    $fcount++;
	    open(OUT,"> $ARGV[0]\_$fcount");
	}
    }
    print OUT $line;
}
close(IN);
close(OUT);
exit(0);
