#!/usr/bin/perl
###############################################################################
# parse_tfprfs.pl
# Author: Robert M. Stephens
# e.g. parse_tfprfs.pl promoters.tfprfs > promoters.tfprfs.parse
#################################################################################
$ARGV[0]=~/(\S+)\.tfprfs/;
$root=$1;
open(IN,"$root.seq");

#>RPS11_Prm0 chr19:49998135-49999834(+) GeneID:6205 Refseq:NM_001015.3
#GCCTTTAGCCACATGTGGCTATTTAGATATAACACAATCAAAGTTAAACATTTATGTCCTCAGTCATAA
#AGCCACATTTAGAGTGCCAGTGACTACCGTGTCCACCAGCGCAGATATAGAAAATTTCCATCACATAAA

while($line=<IN>) {
    if($line !~ /^>(\S+)/) {next;}
    $id=$1;
    $line=~/(chr\S+):(\d+)-(\d+)\((\S)/;
    $chroms{$id}=$1;
    $starts{$id}=$2;
    $stops{$id}=$3;
    $strands{$id}=$4;
}
close(IN);

open(IN,$ARGV[0]);

$done=0;

open(GEN,"> $root.genomic.tfprfs");
while(! $done) {
    getRecd();
    @rows=split(/\n/,$recd);
    $rows[0]=~/sequence ID\s+(\S+)/;
    $id=$1;
    $id=~s/-\d$//;
    for($i=1;$i<=$#rows;$i++) {
	$rows[$i]=~s/ //g;
	@fields=split(/\|/,$rows[$i]);
	if($#fields<4) {next;}
        $site_prf=$fields[0];
	$fields[1]=~/(\d+)\((\S)/;
	$s=$1;
	$strand=$2;
	if($strands{$id} eq "+") {
	    $b=$s-1500;
	    $e=$b+length($fields[4]);
	    $gb=$starts{$id}+$b+1500;
	    $ge=$starts{$id}+$e+1500;
	    $st="plus";
	}
	else{
	    $b=$s-1500;
	    $e=$b+length($fields[4]);
	    $gb=$stops{$id}-$e+1500;
	    $ge=$stops{$id}-$b+1500;
	    $st="minus";
	}
        $prob1=$fields[2];
        $prob2=$fields[3];
	$site=$fields[4];
	print  "$id\t$site_prf\t$b\t$e\t$strand\t$site\t$prob1\t$prob2\n";
	print GEN "$chroms{$id}\tABCC\tTFPBS\t$gb\t$ge\t.\t$strands{$id}\t";
        print GEN ".\tID=$id\_$site_prf\_$s;TFOrient=$st;";
	print GEN "TFName=$site_prf;PromPos=$b-$e\n";
    }
}
close(IN);
close(GEN);
exit(0);

sub getRecd() {
# move to the next record...
    while($line!~/Inspecting sequence/) 
    {
	$line=<IN>;
	if(! $line) {
	    $done=1;
	    return;
	}
    }
    $recd=$line;
    $line=<IN>;

    while($line!~/^Inspecting sequence/) {
	$recd.=$line;
	$line=<IN>;
	if(! $line) {
	    $done=1;
	    return;
	}
    }
    return;
}
