#!/usr/bin/perl
# ================================================================
# getMPromoters.pl 
# Author: Robert M. Stephens
# Script to extract mirna promoter regions for mapped genes on a genome.
# Makes the following files:
#  1) mpromoters.gff ... gff formatted promoter file for gbrowse
#  1a)mpromoters.grid...grid formatted promoter file for database
#  2) mgene2promoters ... gene to promoter/acc table file
#  3) mpromoters.seq ... fasta formatted sequence file
# NOTE: for now, only output same species promoters.
# ================================================================

if(! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

$offset="/bioinfoA/db_updates/ncbi_genomes/promoters/offset.pl";

if ($ARGV[0] eq "") {
    print "USAGE: getMPromoters.pl <species>\n";
    exit(1);
}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="$AnalyRootDir/$species";

$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");

chdir("$outputdir/$subdir/$mydir");

if(! open(IN,"$outputdir/$subdir/mapping/mirna/hairpin.gmap.gff")) {
    print "Need to generate mirna gene map first\n";
    print "  ($outputdir/$subdir/mapping/mirna/hairpin.gmap.gff)\n";
    exit(1);
}
<IN>;
open(GFF,"> mpromoters.gff");
open(SQL,"> mpromoters2gene");
open(SEQ,"> mpromoters.seq");
open(GRID,"> mpromoters.grid");

print "Processing file: $outputdir/$subdir/mapping/mirna/hairpin.gmap.gff\n";
print GFF "##gff-version 3\n";

while($line=<IN>) {
    chomp($line);
    ($chrom,$d1,$d2,$chbegin,$chend,$d3,$chstrand,$d4,$info)=split(/\t/,$line);
    if($info!~/ID=(\S+);miRNA=(\S+)/) {next;}
    if($d2 eq "xMiRNAAlign") {next;}
    $mirna=$1;
    $acc=$2;
    if($chstrand eq "+") {
	$pstart=$chbegin-1499;
	$pstop=$chbegin+200;
    }
    else {
	$pstart=$chend-200;
	$pstop=$chend+1499;
    }
# see if this is the second hit for this gene...
    if($promoters{$mirna}[0]) {
	$found=0;
	for($d=1;$d<=$promotercount{$mirna};$d++) {
	    if($promoters{$mirna}[$d] eq "$chrom:$pstart-$pstop($chstrand)") {
		$found=1;
	    }
	}
	if($found) {next;}
	$promotercount{$mirna}++;
	$promoters{$mirna}[$promotercount{$mirna}]="$chrom:$pstart-$pstop($chstrand)";
	print GFF "$chrom\tABCC\tMPromoter\t$pstart\t$pstop\t.\t$chstrand\t.\t";
	print GFF "ID=$mirna\_MPrm$promotercount{$mirna};miRNA=$acc";
	print GFF ";Tag=MultiplePromoters";
	print GFF "\n";
	print GRID "$mirna\_Prm$promotercount{$mirna}\t$chrom\t\tMPromoter\tMPromoter\t1\t",$pstop-$pstart+1,"\t$chstrand\t$pstart\t$pstop\t$acc;Multi\n";
	getSeq();
    }
    else {
        print GFF "$chrom\tABCC\tMPromoter\t$pstart\t$pstop\t.\t$chstrand\t.\t";
        print GFF "ID=$mirna\_MPrm0;Acc=$acc";
        print GFF "\n";
        print GRID "$mirna\_Prm0\t$chrom\tMPromoter\tMPromoter\t1\t",$pstop-$pstart+1,"\t$chstrand\t$pstart\t$pstop\t$acc;Single\n";
	getSeq();
	$promotercount{$mirna}=0;
	$promoters{$mirna}[$promotercount{$mirna}]="$chrom:$pstart-$pstop($chstrand)";
    }
    print SQL "$mirna\t$mirna\_Prm$promotercount{$mirna}\t0\t$acc\t$chrom\t$pstart\t$pstop\t$chstrand\n";

}

close(IN);
close(GFF);
close(SQL);
close(SEQ);
close(GRID);

$a=qx+$offset mpromoters.seq > mpromoters.offset+;
print "done extracting mpromoters\n";
$a=qx+ls -al+;
print $a;

exit(0);

sub getSeq() {
    $file="$dwnlddir/$subdir/chromosomes/$chrom_prefixes{$species}$chrom$chrom_suffixes{$species}";
    if(! $promotercount{$mirna}) {$promotercount{$mirna}=0;}
    $cmd="/bioinfoA/apps/perl/fetch2.pl $file $pstart $pstop $chstrand| grep -v '>'";
    #print "$cmd\n";
    $a=qx+$cmd+;
    print SEQ ">$mirna\_Prm$promotercount{$mirna} $chrom:$pstart-$pstop($chstrand) Acc:$acc\n";
    print SEQ $a;
    return;
}
