#!/usr/bin/perl
# =================================================
# Author: Robert M. Stephens
# This perl script writes out the sql code to load
#  a mysql database with new/updated mirna promoter data.
# You need to load the base promoter associated tables
#  separately (tfsites table).
# Comments extended by Regina Z. Cer
# =================================================

if(! $ENV{$ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

if ($ARGV[2] eq "") 
{
    print "USAGE: loader_prom.pl <species> <folder> <subset: .|m|x> <version>\n";
    print "e.g. ./loader_prom.pl human 20090918 . 37\n";
    exit(1);
}

require("/bioinfoA/db_updates/ncbi_genomes/lookups.pl");
$species=$ARGV[0]; 
$s=substr($species,0,1);
$s2=substr($species,1); 
$s=~tr/a-z/A-Z/; 
$sp=$s.$s2;

# prefixes: m=mirna, x=cross
if($ARGV[2] eq "x" || $ARGV[2] eq "m") {$pre=$ARGV[2];}
else{$pre="";}

# set up some defaults...
$dwnlddir="/bioinfoA/dwnld/ncbi_genomes/$species";
$outputdir="/bioinfoB/ncbi_genomes/$species";

$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");
$dir="$outputdir/$subdir/$mydir";
$db="GRID_$sp\_$ARGV[3]"; #GRID_Human_37

$flag=0;
open(SQL,"> sql/$ARGV[0]\_prom.$pre.sql");
print SQL "# $ARGV[0] $pre\Promoter Database Loader Script\n";
print SQL "create database if not exists $db;\n";
print SQL "use $db;\n";
print SQL "drop table if exists $pre\prom_sites;\n";
&printCHT("$pre\prom_sites");
print SQL "drop table if exists $pre\prom2gene;\n";
&printCPT("$pre\prom2gene");
print SQL "drop table if exists $pre\prom_strs;\n";
&printCST("$pre\prom_strs");
print SQL "drop table if exists $pre\prom_rpts;\n";
&printCRT("$pre\prom_rpts");
print SQL "drop table if exists $pre\prom_comp;\n";
&printCCT("$pre\prom_comp");
print SQL "drop table if exists $pre\prom_genscan;\n";
&printCGT("$pre\prom_genscan");
print SQL "drop table if exists $pre\prom_stems;\n";
&printCET("$pre\prom_stems");
print SQL "drop table if exists $pre\prom_snps;\n";
&printCSPT("$pre\prom_snps");
print SQL "drop table if exists $pre\prom_rmsks;\n";
&printCRMT("$pre\prom_rmsks");
print SQL "drop table if exists $pre\prom_tfprfs;\n";
&printPPT("$pre\prom_tfprfs");
print SQL "drop table if exists $pre\prom_info;\n";
&printPIT("$pre\prom_info");
print SQL "drop table if exists $pre\prom_retrieval_info;\n";
&printPRT("$pre\prom_retrieval_info");

if(-e "$dir/$pre\promoters2gene") {
    print SQL "load data local infile \"$dir/$pre\promoters2gene\" into table $pre\prom2gene;\n";
    print SQL "load data local infile \"$dir/$pre\promoters.strs\" into table $pre\prom_strs;\n";
    print SQL "load data local infile \"$dir/$pre\promoters.rpts\" into table $pre\prom_rpts;\n";
    print SQL "load data local infile \"$dir/$pre\promoters.comp\" into table $pre\prom_comp;\n";
    #print SQL "load data local infile \"$dir/$pre\promoters.snps\" into table $pre\prom_snps;\n";
    #print SQL "load data local infile \"$dir/$pre\promoters.rmsks\" into table $pre\prom_rmsks;\n";
    print SQL "load data local infile \"$dir/$pre\promoters.genscan\" into table $pre\prom_genscan;\n";
    print SQL "load data local infile \"$dir/$pre\promoters.stems\" into table $pre\prom_stems;\n";
    print SQL "load data local infile \"$dir/$pre\promoters.grid\" into table $pre\prom_info;\n";
    print SQL "load data local infile \"$dir/$pre\promoters.offset\" into table $pre\prom_retrieval_info;\n";
    print SQL "load data local infile \"$dir/$pre\promoters.tfsites\" into table $pre\prom_sites;\n";
    print SQL "load data local infile \"$dir/$pre\promoters.tfprfs.parse\" into table $pre\prom_tfprfs;\n\n";    print SQL "exit\n";
}

close(SQL);

print "Script written into sql directory.\n";
print "Now, you can load it like:\n";
print "mysql -p -h <host> <sql/scriptname>\n";

exit(0);

sub printCHT() {
    ($name)=$_[0];
    print SQL "create table if not exists $name (\n";
    print SQL "`promoter` varchar(25) default NULL,\n";
    print SQL "`sitename` varchar(40) default NULL,\n";
    print SQL "`start` integer default NULL,\n";
    print SQL "`stop` integer default NULL,\n";
    print SQL "`strand` varchar(1) default NULL,\n";
    print SQL "`site` varchar(25) default NULL,\n";
    print SQL "KEY `promoter` (`promoter`),\n";
    print SQL "KEY `sitename` (`sitename`),\n";
    print SQL "KEY `start` (`start`),\n";
    print SQL "KEY `stop` (`stop`));\n";
    return;
}

sub printCPT() {
    ($name)=$_[0];
    print SQL "CREATE TABLE if not exists $name (\n";
    print SQL "`genename` varchar(20) default NULL,\n";
    print SQL "`promoter` varchar(25) default NULL,\n";
    print SQL "`geneid` integer,\n";
    print SQL "`mrnaacc` varchar(15) default NULL, \n";
    print SQL "`chrom` varchar(12) default NULL,\n";
    print SQL "`start` integer default NULL,\n";
    print SQL "`stop` integer,\n";
    print SQL "`strand` char,\n";
    print SQL "KEY `promoter` (`promoter`),\n";
    print SQL "KEY `chrom` (`chrom`),\n";
    print SQL "KEY `start` (`start`),\n";
    print SQL "KEY `stop` (`stop`)\n";
    print SQL ");\n";
    return;
}

sub printCST() {
    ($name)=$_[0];
    print SQL "CREATE TABLE if not exists $name (\n";
    print SQL "`promoter` varchar(25) default NULL,\n";
    print SQL "`start` integer default NULL,\n";
    print SQL "`stop` integer,\n";
    print SQL "`rpt` varchar(16),\n";
    print SQL "`nbr` integer,\n";
    print SQL "`seq` varchar(255),\n";
    print SQL "KEY `promoter` (`promoter`),\n";
    print SQL "KEY `start` (`start`),\n";
    print SQL "KEY `stop` (`stop`)\n";
    print SQL ");\n";
    return;
}

sub printCRT() {
    ($name)=$_[0];
    print SQL "CREATE TABLE if not exists $name (\n";
    print SQL "`promoter` varchar(25) default NULL,\n";
    print SQL "`start` integer default NULL,\n";
    print SQL "`rpt` varchar(100),\n";
    print SQL "`postn` varchar(255),\n";
    print SQL "KEY `promoter` (`promoter`),\n";
    print SQL "KEY `start` (`start`)\n";
    print SQL ");\n";
    return;
}

sub printCCT() {
    ($name)=$_[0];
    print SQL "CREATE TABLE if not exists $name(\n";
    print SQL "`promoter` varchar(25) default NULL,\n";
    print SQL "`cnta` int default 0,\n";
    print SQL "`cntc` int default 0,\n";
    print SQL "`cntg` int default 0,\n";
    print SQL "`cntt` int default 0,\n";
    print SQL "`cntn` int default 0,\n";
    #print SQL "`cntac` int default 0,\n";
    #print SQL "`cntag` int default 0,\n";
    #print SQL "`cntat` int default 0,\n";
    print SQL "`fraca` double default 0.0,\n";
    print SQL "`fracc` double default 0.0,\n";
    print SQL "`fracg` double default 0.0,\n";
    print SQL "`fract` double default 0.0,\n";
    print SQL "`fracn` double default 0.0,\n";
    print SQL "`fracac` double default 0.0,\n";
    print SQL "`fracag` double default 0.0,\n";
    print SQL "`fracat` double default 0.0);\n";
    return;
}

sub printCSPT() {
    ($name)=$_[0];
    print SQL "CREATE TABLE if not exists $name(\n";
    print SQL "`promoter` varchar(25) default null,\n";
    print SQL "`snpid` varchar(12) default null,\n";
    print SQL "`pos` int default 0);\n";
    return;
}

sub printCET() {
    ($name)=$_[0];
    print SQL "CREATE TABLE if not exists $name(\n";
    print SQL "`promoter` varchar(25),\n";
    print SQL "`status` varchar(15),\n";
    print SQL "`len` integer,\n";
    print SQL "`begin1` integer,\n";
    print SQL "`end1` integer,\n";
    print SQL "`seq1` varchar(50),\n";
    print SQL "`begin2` integer,\n";
    print SQL "`end2` integer,\n";
    print SQL "`seq2` varchar(50));\n";
    return;
}

sub printCRMT() {
    ($name)=$_[0];
    print SQL "CREATE TABLE if not exists $name(\n";
    print SQL "`promoter` varchar(25) default null,\n";
    print SQL "`rmskname` varchar(20) default null,\n";
    print SQL "`start` int default 0,\n";
    print SQL "`stop` int default 0);\n";
    return;
}

sub printCGT() {
    ($name)=$_[0];
    print SQL "CREATE TABLE if not exists $name(\n";
    print SQL "`promoter` varchar(25) default null,\n";
    print SQL "`result` varchar(80) default null);\n";
    return;
}

sub printPPT() {
    ($name)=$_[0];
    print SQL "create table if not exists $name(\n";
    print SQL "`promoter` varchar(25) default null,\n";
    print SQL "`profile` varchar(15) default null,\n";
    print SQL "`start` int default 0,\n";
    print SQL "`stop` int default 0,\n";
    print SQL "`strand` char(1),\n";
    print SQL "`site` varchar(25) default null,\n"; 
    print SQL "`prob1` float default 0,\n";
    print SQL "`prob2` float default 0,\n";
    print SQL "KEY `promoter` (`promoter`),\n";
    print SQL "KEY `profile` (`profile`),\n";
    print SQL "KEY `start` (`start`),\n";
    print SQL "KEY `stop` (`stop`));\n"; 
    return;
}

sub printPIT() {
    ($name)=$_[0];
    print SQL "CREATE TABLE if not exists $name (\n";
    print SQL "  `name` varchar(45) default NULL,\n";
    print SQL "  `chrom` varchar(12) default NULL,\n";
    print SQL "  `category` varchar(20) default NULL,\n";
    print SQL "  `type` varchar(99) default NULL,\n";
    print SQL "  `nbr` int(11) default NULL,\n";
    print SQL "  `len` int(11) default NULL,\n";
    print SQL "  `strand` char(1) default NULL,\n";
    print SQL "  `start` int(11) default NULL,\n";
    print SQL "  `stop` int(11) default NULL,\n";
    print SQL "  `info` varchar(30) NOT NULL,\n";
    print SQL "  KEY `name` (`name`),\n";
    print SQL "  KEY `chrom` (`chrom`),\n";
    print SQL "  KEY `start` (`start`),\n";
    print SQL "  KEY `stop` (`stop`),\n";
    print SQL "  KEY `category` (`category`),\n";
    print SQL "  KEY `type` (`type`),\n";
    print SQL "  KEY `nbr` (`nbr`),\n";
    print SQL "  KEY `len` (`len`)\n";
    print SQL ");\n";
    return;
}

sub printPRT() {
    ($name)=$_[0];
    print SQL "CREATE TABLE if not exists $name (\n"; 
    print SQL " `file` varchar(30) NOT NULL,\n";
    print SQL "  `traceid` varchar(20) NOT NULL,\n";
    print SQL "  `offset` int(11) NOT NULL,\n";
    print SQL "  `bytes` int(11) NOT NULL\n";
    print SQL ");\n"; 
    return;
}

