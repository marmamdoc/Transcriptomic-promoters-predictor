#!/usr/bin/perl
# =================================================
# This perl script writes out the sql code to load
#  a mysql database with new/updated mirna promoter data.
# You need to load the base promoter associated tables
#  separately (tfsites table).
# =================================================

if(! $ENV{$ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

if ($ARGV[1] eq "") {
    print "USAGE: loader_snpinfo.pl <database> <species>\n";
    exit(1);
}

require("/bioinfoA/db_updates/ncbi_genomes/lookups.pl");
$db=$ARGV[0];
$species=$ARGV[1];

# set up some defaults...
$datadir="/bioinfoB/dwnld/dbsnp/$species/human.36";

open(SQL,"> $ARGV[1]\_snps.sql");
print SQL "# $ARGV[0]$pre\GRID SNP Database Loader Script\n";
print SQL "create database if not exists $db;\n";
print SQL "use $db;\n";
print SQL "drop table if exists I_SnpImpacts;\n";
&printCHT("I_SnpImpacts");
print SQL "drop table if exists I_Snps;\n";
&printCPT("I_Snps");

opendir(D,$datadir);
while($file=readdir(D)) {
    if($file=~/\.snpinfo/) {
	print SQL "load data local infile \"$datadir/$file\" into table I_Snps;\n";
    }
    elsif($file=~/\.geneimpacts/) {
	print SQL "load data local infile \"$datadir/$file\" into table I_SnpImpacts;\n";
    }
}

close(SQL);

print "Script written into sql directory.\n";
print "Now, you can load it like:\n";
print "mysql -p -h <host> <sql/scriptname>\n";

exit(0);

sub printCHT() {
    ($name)=$_[0];
    print SQL "create table if not exists $name (\n";
    print SQL "`snpid` varchar(12) default NULL,\n";
    print SQL "`gene` varchar(12) default NULL,\n";
    print SQL "`mrna` varchar(12) default NULL,\n";
    print SQL "`protein` varchar(12) default NULL,\n";
    print SQL "`impact` varchar(25) default NULL,\n";
    print SQL "`frame` tinyint default NULL,\n";
    print SQL "`aapos` mediumint,\n";
    print SQL "`allele` varchar(5),\n";
    print SQL "`residue` char(1));\n";
    return;
}

sub printCPT() {
    ($name)=$_[0];
    print SQL "CREATE TABLE if not exists $name (\n";
    print SQL "`snpid` varchar(12) default NULL,\n";
    print SQL "`chrom` varchar(5) default NULL,\n";
    print SQL "`position` integer,\n";
    print SQL "`alleles` varchar(20) default NULL, \n";
    print SQL "`het` float default NULL,\n";
    print SQL "`stderr` float default NULL);\n";
    return;
}
