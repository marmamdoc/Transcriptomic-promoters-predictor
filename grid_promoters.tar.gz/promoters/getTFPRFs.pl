#!/usr/bin/perl
# ==============================================================
# Author: Robert M. Stephens
# Script to obtain transcription factor profiles  within an input file of sequence
# Comments extended by Regina Z. Cer 
# 04/06/2010 RZC changed code to use Match 8.3 vesion
# 05/27/2010 RZC used minSUM profiles
# 12/16/2010 RZC changed to use Match 8.6 version
# ==============================================================

if(! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

$match="/bioinfoA/apps/Linux/transfac/2010/bin/match";

$matrix="/bioinfoA/apps/Linux/transfac/2010/data/matrix.dat";

$profile="/bioinfoA/apps/Linux/transfac/2010/data/prfs/vertebrate_non_redundant_minSUM.prf";

$parser="/bioinfoA/db_updates/ncbi_genomes/promoters/parse_tfprfs.pl";

if($ARGV[0] eq "") 
{
    print "USAGE: getTFPRFs.pl <species> <fldr> <- or m or x>\n";
    print "USAGE: getTFPRFs.pl human 20090918 m"; #for mRNA
    exit(1);
}

if($ARGV[2] ne "" && $ARGV[2] ne ".") {$addon=$ARGV[2];}
else{$addon="";}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="/$AnalyRootDir/$species";

# get the latest directory of updates for this species...
$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");

#change to /bioinfoB/ncbi_genomes/human/20090918/promoters
chdir("$outputdir/$subdir/$mydir");

$cmd="$match $matrix ". $addon."promoters.seq ".$addon."promoters.tfprfs $profile";
#match matrix.dat /bioinfoB/ncbi_genomes/human/20090918/promoters/mpromoters.seq m.promoters.tfprfs minFN_good102.prf 
print "$cmd\n";
$a=qx+$cmd+;
$cmd="$parser ".$addon."promoters.tfprfs > ".$addon."promoters.tfprfs.parse";
print "$cmd\n";
$a=qx+$cmd+;
$cmd="chmod 775 *";
$a=qx+$cmd+;
print "done processing tfprfs\n";
$a=qx+ls -al+;
print $a;

exit(0);
