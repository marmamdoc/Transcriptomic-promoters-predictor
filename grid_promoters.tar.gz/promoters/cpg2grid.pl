#!/usr/bin/perl
open(IN,$ARGV[0]);
while($line=<IN>) {
    if($line=~/NEWCPGSEEK of (\S+)/) {
	$name=$1;
    }
    elsif($line=~/(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+([\d\.]+)\s+([\d\.]+)/) {
	print "$name\t$1\t$2\t$3\t$4\t$5\t$6\n";
    }
}
close(IN);
exit(0);
