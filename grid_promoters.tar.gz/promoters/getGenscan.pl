#!/usr/bin/perl
# =======================================================================
# Script to run genscan on an input file of sequences (promoter regions).
# =======================================================================

if(! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

$genscan="/bioinfoA/apps/Linux/genscan/genscan /bioinfoA/apps/Linux/genscan/HumanIso.smat";

if($ARGV[0] eq "") {
    print "USAGE: getGenscan.pl <species> <folder or .> <type>\n";
    exit(1);
}

if($ARGV[2] eq "x" || $ARGV[2] eq "m") {$addon=$ARGV[2];}
else{$addon="";}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="$AnalyRootDir/$species";

# get the latest directory of updates for this species...
$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");
chdir("$outputdir/$subdir/$mydir");

open(IN,$addon."promoters.seq");
open(OUT,"> ".$addon."promoters.genscan");

while($line=<IN>) {
    if($line=~/^>(\S+)/) {
	if($seq) {&processSeq();}
        $seq="";
        $acc=$1;
    }
    else {$seq.=$line;}
}
close(IN);
if($seq) {&processSeq();}
close(OUT);
print "done with genscan\n";
$a=qx+ls -al+;
print $a;

exit(0);

sub processSeq() {
    open(T,"> $addon"."gtestseq");
    print T ">$acc\n$seq";
    close(T);
    $cmd="$genscan $addon"."gtestseq 2>/dev/null";
    $a=qx+$cmd+;
    if($a=~/NO EXONS/) {print OUT "$acc\tNONE Found\n";}
    else {
	$start=index($a,"----- ----");
        $stop=index($a,"Predicted peptide");
        $b=substr($a,$start+1,$stop-1-$start);
        @rows=split(/\n/,$b);
        for($i=2;$i<=$#rows;$i++) {print OUT "$acc\t$rows[$i]\n";}
    }   
    return;
}

