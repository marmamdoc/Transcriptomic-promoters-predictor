#!/usr/bin/perl
# ==============================================================
# Author: Robert M. Stephens
# Script to obtain transcription factor profiles  within an input file of sequence
# Comments extended by Regina Z. Cer 
# 04/06/2010 RZC changed code to use Match 8.3 vesion
# 05/27/2010 RZC used minSUM profiles
# 12/16/2010 RZC changed to use Match 8.6 version
# ==============================================================

if(! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

#$match="/bioinfoA/apps/Linux/transfac/2007/match";
#$match="/bioinfoA/apps/Linux/transfac/2009/match";
$match="/bioinfoA/apps/Linux/transfac/2010/bin/match";

#$matrix="/bioinfoA/apps/Linux/transfac/matrix.114.dat";
#$matrix="/bioinfoA/apps/Linux/transfac/2009/matrix.dat";
$matrix="/bioinfoA/apps/Linux/transfac/2010/data/matrix.dat";

#$profile="/bioinfoA/apps/Linux/transfac/all_minFP_highQual.prf";
#$profile="/bioinfoA/apps/Linux/transfac/2009/prfs/vertebrate_non_redundant_minSUM.prf";
#$profile="/bioinfoA/apps/Linux/transfac/2009/prfs/vertebrate_non_redundant_minFN.prf"; 
#04/22/2010 since minSUM gives too few(?)

# 12/16/2010 RZC: minFN_good.prf  minFN.prf  minFP_good.prf  minFP.prf  minSUM_good.prf  minSUM.prf
# Question: should we be using minSUM_good.prf instead
#1039 minSUM_good.prf
#1342 minSUM.prf
#225 prfs/vertebrate_non_redundant_minSUM.prf
$profile="/bioinfoA/apps/Linux/transfac/2010/data/prfs/vertebrate_non_redundant_minSUM.prf";

$parser="/bioinfoA/db_updates/ncbi_genomes/promoters/parse_tfprfs.pl";

if($ARGV[0] eq "") 
{
    print "USAGE: getTFPRFsminSum.pl <species> <fldr> <- or m or x>\n";
    print "USAGE: getTFPRFsminSum.pl human 20090918 m"; #for miRNA
    exit(1);
}

if($ARGV[2] ne "" && $ARGV[2] ne ".") {$addon=$ARGV[2];}
else{$addon="";}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="/$AnalyRootDir/$species";

# get the latest directory of updates for this species...
$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");

chdir("$outputdir/$subdir/$mydir");
$cmd="$match $matrix ". $addon."promoters.seq ".$addon."promoters.tfprfs.minSUM $profile";
#match matrix.dat /bioinfoB/ncbi_genomes/human/20090918/promoters/mpromoters.seq m.promoters.tfprfs minFN_good102.prf 
print "$cmd\n";
$a=qx+$cmd+;
$cmd="$parser ".$addon."promoters.tfprfs.minSUM > ".$addon."promoters.tfprfs.minSUM.parse";
print "$cmd\n";
$a=qx+$cmd+;
$cmd="chmod 664 *";
$a=qx+$cmd+;
print "done processing tfprfs with minSUM profile\n";
$a=qx+ls -al+;
print $a;

exit(0);
