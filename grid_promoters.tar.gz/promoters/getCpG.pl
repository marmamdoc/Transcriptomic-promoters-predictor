#!/usr/bin/perl
# ==============================================================
# Run Genscan on a Genome. Each chromosome is chopped up into
#  fragments (1mbp with a 100kb overlap) and then run through
#  genscan. Chunks are generated using fetch2.pl
# Outputs need to be parsed to accomodate this overlap.
# ==============================================================
if(! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

if(! $ARGV[0]) {
    print "USAGE: getCpG.pl <species> <fldr> <type>\n";
    exit(1);
}
if($ARGV[2] eq "x" || $ARGV[2] eq "m") {$addon=$ARGV[2];}
else{$addon="";}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="$AnalyRootDir/$species";
$scriptdir="$ENV{ScriptHome}/promoters";

# get the latest directory of updates for this species...
$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");

chdir("$outputdir/$subdir/$mydir");
$cmd="newcpgseek -sequence ";
$cmd.=$addon."promoters.seq"; 
$cmd.=" -outfile ".$addon."promoters.cpg -score 30";
$a=qx+$cmd+;
$cmd="$scriptdir/cpg2grid.pl $addon"."promoters.cpg > ".$addon."promoters.cpg.grid";
$a=qx+$cmd+;
closedir(D);
print "done cpg analysis\n";
$a=qx+ls -al+;
print $a;

exit(0);
