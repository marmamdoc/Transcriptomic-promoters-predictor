#!/usr/bin/perl
# =============================================================
# Script to identify repeatmasker elements within promoter
#  regions without using the mysql database for the lookups.
# Both the promoter limits and the repeats are readinto memory.
# =============================================================
if($ARGV[0] eq "") {
    print "USAGE: getRmsks.pl <database directory> <value>\n";
    exit(1);
}

open(IN,"/bioinfoA/parse/GRID/$ARGV[0]/$ARGV[0].$ARGV[1]"."prom.info");
open(OUT,"> /bioinfoA/parse/GRID/$ARGV[0]/$ARGV[0].$ARGV[1]"."prom.snps");
#open(OUT,"> z");

$c=0;
while($line=<IN>) {
    chop($line);
    ($dupname,$name,$chrom,$start,$stop,$strand,$info)=split(/\t/,$line);
    $pchroms{$name}=$chrom;
    $pstarts{$name}=$start;
    $pstrands{$name}=$strand;
    $pstops{$name}=$stop;
    $c++;
}
close(IN);

print "Finding SNPs elements within promoter regions for $ARGV[0].\n";
print "===> Read $c promoter limits.\n";

opendir(D,"/bioinfoA/parse/GRID/$ARGV[0]");
while($file=readdir(D)) {
    %sstarts=();
    %sstops=();
    %schroms=();
    $pcount=0;
    $scount=0;
    $d=0;
    if($file!~/snp/ && $file!~/bgiSnp/) {next;}
    open(IN,"/bioinfoA/parse/GRID/$ARGV[0]/$file");
    while($line=<IN>) {
	chop($line);
	($name,$chrom,$cat,$typ,$nbr,$len,$strand,$start,$stop)=split(/\t/,$line);
	$schroms{$name}=$chrom;
	$sstarts{$name}=$start;
	$sstops{$name}=$stop;
	$d++;
#       if($d % 100000 == 0) {print "$d\n";}
#       if($d>100000) {last;}
    }
    close(IN);
    print "===> Read $d snps for file $file.\n";
    foreach $key (keys %pchroms) {
        $pcount++;
	foreach $item (keys %schroms) {
            if($schroms{$item} ne $pchroms{$key}) {next;}
	    if($sstarts{$item}<$pstarts{$key}) {next;}
	    if($sstarts{$item}>$pstops{$key}) {next;}
            $scount++;
	    print OUT "$key\t$item\t";
            if($pstrands{$key} eq "+") {
		$a=$sstarts{$item}-$pstarts{$key};
		if($a<0) {$s=-1500;}
		else{$s=$a-1500;}
		print OUT "$s\n";
	    }
	    else {
		$a=$pstops{$key}-$sstops{$item};
		if($a<0) {$s=-1500;}
		else{$s=$a-1500;}
		print OUT "$s\n";
	    }
	}
# remove this ites from the list..
    }
    print "     Found $scount snp hits on $pcount promoter regions.\n";
    $c-=$pcount;
    print "     ($c promoters left to search)\n";
}
exit(0);
