#!/usr/bin/perl
# ======================================================
# find simple repeats from sequences.
# ======================================================

if(! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

if($ARGV[0] eq "") {
  print "USAGE: findStrs.pl <species> <fldr> <- or x or m> <min> <max> <nbr>\n";
  exit;
}
if($ARGV[2] ne "" && $ARGV[2] ne ".") {$addon=$ARGV[2];}
else{$addon="";}
if($ARGV[3] ne "" && $ARGV[3] ne ".") {$min=$ARGV[3];}
else{$min=2;}
if($ARGV[4] ne "" && $ARGV[4] ne ".") {$max=$ARGV[4];}
else{$max="16";}
if($ARGV[5] ne "" && $ARGV[5] ne ".") {$nbr=$ARGV[5];}
else{$nbr=4;}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="$AnalyRootDir/$species";

# get the latest directory of updates for this species...
$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");
chdir("$outputdir/$subdir/$mydir");

$count=0;
$regexp="(([GATC]{$min,$max}?)\\2{$nbr,})";
$debug=1;

open(SEQ,$addon."promoters.seq");
open(OUT,"> ".$addon."promoters.strs");

$done=0;
$line=<SEQ>;

while (! $done) {
    &readSeq();
    $seq=~s/\s//g;
    $seq=~tr/a-z/A-Z/;
    $seqtitle=~/>(\S+)/;
    $name=$1;
    #print "\nAnalyzing sequence $name (",length($seq)," bp):\n";
    $count++;
    &findStrs();
}
#print "Read $count sequences.\n";
close(SEQ);
close(OUT);
print "done finding strs\n";
$a=qx+ls -al+;
print $a;

exit 0;

# -----------------------------------------------------------------------
sub readSeq() {
# Read until the next '>' character. Convert sequence to upper case.
    $seqtitle=$line;
    $seq="";
    while ($line=<SEQ>) {
	if ($line=~/^>/) {
            return;
        }
	$seq.=$line;
    }
    $done=1;
    return;
}

# -----------------------------------------------------------------------
sub findStrs() {
    while($seq=~/$regexp/ig) {
	$stop=pos($seq)-1500;
	$start=$stop-length($1)+1;
        $hit=$2;
        $repl=$1;
        $r=$repl;
        $r=~tr/A-Z/A-Z/s;
	if(length($r) == 1 && $min>1) {next;}
 # need a better way to clean up these...
        $l=length($hit);
        $ne=length($repl)/$l;
        $name=~s/^gi\|//;
	print OUT "$name\t$start\t$stop\t$hit\t$ne\t$repl\n";
    }
    return;
}
