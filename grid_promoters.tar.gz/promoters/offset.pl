#!/usr/bin/perl
# ===========================================================
# perl script that outputs information for byte offset
#  based file reads. Offset and length of record is output.
# Uses fasta base file descriptor to signal a new object.
# ==========================================================

open(IN,$ARGV[0]);
$offset=0;
$a=rindex($ARGV[0],"/");
if($a>-1) {$file=substr($ARGV[0],$a+1);}
else{$file=$ARGV[0];}

while($line=<IN>) {
    if($line=~/^>(\S+)/) {
	if($title) {
	    $pos=tell(IN)-length($line);
	    $len=$pos-$offset;
	    print "$file\t$title\t$offset\t$len\n";
	    $offset=$pos;
	}
	$title=$1;
	$title=~s/gnl\|ti\|//g;
    }
}

if($title) {
    $len=tell(IN)-$offset;
    print "$file\t$title\t$offset\t$len\n";
}
close(IN);
exit(0);
