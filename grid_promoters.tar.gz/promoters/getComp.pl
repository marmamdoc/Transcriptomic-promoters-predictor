#!/usr/bin/perl
# =======================================================================
# Script to get the composition of promoter (or other sequence) regions.
# =======================================================================

if(! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

if ($ARGV[0] eq "") {
    print "USAGE: getComp.pl <species> <folder or .> <- or x or m>\n";
    exit(1);
}
if($ARGV[2] eq "x" || $ARGV[2] eq "m") {$addon=$ARGV[2];}
else{$addon="";}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="$AnalyRootDir/$species";

# get the latest directory of updates for this species...
$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");
chdir("$outputdir/$subdir/$mydir");

open(IN,$addon."promoters.seq");
open(OUT,"> ".$addon."promoters.comp");

while($line=<IN>) {
    if($line=~/^>/) {
	if($seq) {
	    &printComp();
	}
	$seq="";
	$title=$line;
	$title=~/^>(\S+)/;
	$acc=$1;
    }
    else{$seq.=$line;}
}
if($seq) {&printComp();}
close(OUT);
close(IN);
print "done calculating comp\n";
$a=qx+ls -al+;
print $a;

exit(0);

# ---------------------------------------------------------------------
sub printComp() {
    $seq=~s/\s//g;
    $seq=~tr/a-z/A-Z/;
    %comp=();
    $m=length($seq);
    for($i=0;$i<$m;$i++) {
	$nuc=substr($seq,$i,1);
	$comp{$nuc}++;
    }
    $comp{'ac'}=$comp{'A'}+$comp{'C'};
    $comp{'ag'}=$comp{'A'}+$comp{'G'};
    $comp{'at'}=$comp{'A'}+$comp{'T'};
    printf OUT "%s",$acc;
    printf OUT "\t%d\t%d\t%d\t%d\t%d",
           $comp{'A'},$comp{'C'},$comp{'G'},$comp{'T'},$comp{'N'};
    printf OUT "\t%4.3f\t%4.3f\t%4.3f\t%4.3f\t%4.3f\t%4.3f\t%4.3f\t%4.3f\n",
           $comp{'A'}/$m,$comp{'C'}/$m,$comp{'G'}/$m,$comp{'T'}/$m,
           $comp{'N'}/$m,$comp{'ac'}/$m,$comp{'ag'}/$m,$comp{'at'}/$m;
    $tb+=$m;
}
