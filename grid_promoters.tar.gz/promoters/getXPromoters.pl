#!/usr/bin/perl
# ================================================================
# getXpromoters.pl
# Author: Robert M. Stephens
# Script to extract promoter regions for mapped genes on a genome.
# Makes the following files:
#  1) xpromoters.gff ... gff formatted promoter file for gbrowse
#  1a)xpromoters.grid...grid formatted promoter file for database
#  2) xgene2promoters ... gene to promoter/acc table file
#  3) xpromoters.seq ... fasta formatted sequence file
# Comments extended by Regina Z. Cer
# ================================================================

if(! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

$offset="$ENV{ScriptHome}/promoters/offset.pl";

if ($ARGV[1] eq "") {
    print "USAGE: getXPromoters.pl <species> <fldr or .> <cross>\n";
    print "Example: getXPromoters.pl human mouse\n";
    #e.g. <cross>=mouse
    exit(1);
}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];
$cross=$ARGV[2];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="$AnalyRootDir/$species";

$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");

chdir("$outputdir/$subdir/$mydir");

#/bioinfoB/ncbi_genomes/human/20090918/mapping/refseq/Mus_musculus.gmap.gff

if(! open(IN,"$outputdir/$subdir/mapping/refseq/$species_names{$cross}.gmap.gff")) {
    print "Need to generate refseq gene map for $specie_names{$cross}first\n";
    print "  ($outputdir/$subdir/mapping/refseq/$species_names{$cross}.gmap.gff)\n";
    exit(1);
}

open(GFF,"> xpromoters.gff");
open(SQL,"> xpromoters2gene");
open(SEQ,"> xpromoters.seq");
open(GRID,"> xpromoters.grid");

print "Processing file: $outputdir/$subdir/mapping/refseq/$species_names{$cross}.gmap.gff\n";
print GFF "##gff-version 3\n";

while($line=<IN>) {
    chomp($line);
    ($chrom,$d1,$d2,$chbegin,$chend,$d3,$chstrand,$d4,$info)=split(/\t/,$line);
    if($d2 ne "xRefseqAlign") {next;}
    $info=~/ID=(\S+);Genename=(\S+);GeneID=(\d+);Species=(\S+)/;
    $acc=$1;
    $genename=$2;
    $geneid=$3;
    $xspecies=$4;
# for now skip entries with truncated genename records...
    if(! $genename) {print "$no genename query\n";next;}

    if($chstrand eq "+") {
        $pstart=$chbegin-1499;
        $pstop=$chbegin+200;
    }
    if($chstrand eq "+") {
	$pstart=$chbegin-1499;
	$pstop=$chbegin+200;
    }
    else {
	$pstart=$chend-200;
	$pstop=$chend+1499;
    }
# see if this is the second hit for this gene...
    if($promoters{$genename}[0]) {
	$found=0;
	for($d=0;$d<=$promotercount{$genename};$d++) {
	    if($promoters{$genename}[$d] eq "$chrom:$pstart-$pstop($chstrand)") {
		$found=1;
	    }
	}
	if($found) {next;}
	$promotercount{$genename}++;
	print GFF "$chrom\tABCC\tXPromoter\t$pstart\t$pstop\t.\t$chstrand\t.\t";
	print GFF "ID=$genename\_XPrm$promotercount{$genename};Acc=$acc;GeneID=$geneid;Genename=$genename";
	print GFF ";Tag=MultiplePromoters";
	print GFF "\n";
	print GRID "$genename\_Prm$promotercount{$genename}\t$chrom\tXPromoter\tXPromoter\t1\t",$pstop-$pstart+1,"\t$chstrand\t$pstart\t$pstop\t$acc;Multi\n";
	getSeq();
    }
    else {
	$promotercount{$genename}=0;
        print GFF "$chrom\tABCC\tXPromoter\t$pstart\t$pstop\t.\t$chstrand\t.\t";
        print GFF "ID=$genename\_XPrm0;Acc=$acc;GeneID=$geneid;Genename=$genename";
        print GFF "\n";
        print GRID "$genename\_Prm0\t$chrom\tXPromoter\tXPromoter\t1\t",$pstop-$pstart+1,"\t$chstrand\t$pstart\t$pstop\t$acc;Single\n";
	getSeq();
	$promoters{$genename}[0]="$chrom:$pstart-$pstop($chstrand)";
    }
    print SQL "$genename\t$genename\_Prm$promotercount{$genename}\t$geneids{$geneid}\t$acc\t$chrom\t$pstart\t$pstop\t$chstrand\n";
}

close(IN);
close(GFF);
close(SQL);
close(SEQ);
close(GRID);

$a=qx+$offset xpromoters.seq > xpromoters.offset+;
print "done extracting xpromoters\n";
$a=qx+ls -al+;
print $a;

exit(0);

sub getSeq() {
    $file="$dwnlddir/$subdir/chromosomes/$chrom_prefixes{$species}$chrom$chrom_suffixes{$species}";
    if(! $promotercount{$genename}) {$promotercount{$genename}=0;}
    $cmd="/bioinfoA/apps/perl/fetch2.pl $file $pstart $pstop $chstrand| grep -v '>'";
    #print "$cmd\n";
    $a=qx+$cmd+;
    print SEQ ">$genename\_Prm$promotercount{$genename} $chrom:$pstart-$pstop($chstrand) Acc:$acc\n";
    print SEQ $a;
    return;
}
