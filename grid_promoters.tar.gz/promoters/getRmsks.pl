#!/usr/bin/perl
# =============================================================
# Script to identify repeatmasker elements within promoter
#  regions without using the mysql database for the lookups.
# Both the promoter limits and the repeats are readinto memory.
# =============================================================
if($ARGV[0] eq "") {
    print "USAGE: getRmsks.pl <database directory> <value>\n";
    exit(1);
}

open(IN,"/bioinfoA/parse/GRID/$ARGV[0]/$ARGV[0].$ARGV[1].info");
open(OUT,"> /bioinfoA/parse/GRID/$ARGV[0]/$ARGV[0].$ARGV[1].rmsks");
#open(OUT,"> z");

$c=0;
while($line=<IN>) {
    chop($line);
    ($dupname,$name,$chrom,$start,$stop,$strand,$info)=split(/\t/,$line);
    $pchroms{$name}=$chrom;
    $pstarts{$name}=$start;
    $pstrands{$name}=$strand;
    $pstops{$name}=$stop;
    $c++;
}
close(IN);

print "Finding RMSKR elements within promoter regions for $ARGV[0].\n";
print "===> Read $c promoter limits.\n";

opendir(D,"/bioinfoA/parse/GRID/$ARGV[0]");
while($file=readdir(D)) {
    %rstarts=();
    %rstops=();
    %rchroms=();
    $pcount=0;
    $rcount=0;
    $d=0;
    if($file!~/chr(\S+?)\_rmsk\.grid/) {next;}
    $chr=$1;
    $chr=~s/random/NA/;
    open(IN,"/bioinfoA/parse/GRID/$ARGV[0]/$file");
    while($line=<IN>) {
	chop($line);
	($name,$chrom,$cat,$typ,$nbr,$len,$strand,$start,$stop)=split(/\t/,$line);
	$rchroms{$name}=$chrom;
	$rstarts{$name}=$start;
	$rstops{$name}=$stop;
	$d++;
    }
    close(IN);
    print "===> Read $d repeatmasker limits for chrom $chr.\n";
    $f=0;
    foreach $key (keys %pchroms) {
        $f++;
        #if($f % 5000 == 0) {print "    $f\n";}
	if($pchroms{$key} ne $chr) {next;}
        $pcount++;
	foreach $item (keys %rchroms) {
	    if($rstops{$item}<$pstarts{$key}) {next;}
	    elsif($rstarts{$item}>$pstops{$key}) {next;}
            $rcount++;
	    print OUT "$key\t$item\t";
            if($pstrands{$key} eq "+") {
		$a=$rstarts{$item}-$pstarts{$key};
		if($a<0) {$s=-1500;}
		else{$s=$a-1500;}
		$b=$rstops{$item}-$pstarts{$key};
		if($b>1700) {$t=200;}
		else{$t=$b-1500;}
		print OUT "$s\t$t\n";
	    }
	    else {
		$a=$pstops{$key}-$rstops{$item};
		if($a<0) {$s=-1500;}
		else{$s=$a-1500;}
		$b=$pstops{$key}-$rstarts{$item};
		if($b>17000) {$t=200;}
		else{$t=$b-1500;}
		print OUT "$s\t$t\n";
	    }
	}
# remove this ites from the list..
    delete($pchroms{$key});
    }
    print "     Found $rcount rmskr hits on $pcount promoter regions.\n";
    $c-=$pcount;
    print "     ($c promoters left to search)\n";
}
foreach $item (keys %pchroms) {print "$item $pchroms{$item} $pstarts{$item}\n";}
exit(0);
