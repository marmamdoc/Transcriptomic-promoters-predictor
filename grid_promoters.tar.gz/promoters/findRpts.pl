#!/usr/bin/perl
# ======================================================
# find and mask out simple repeats from sequences.
# ======================================================

if(! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

if($ARGV[0] eq "") {
  print "USAGE: findRpts.pl <species> <fldr> <- or m or x>\n";
  exit;
}
if($ARGV[2] eq "x" || $ARGV[2] eq "m") {$addon=$ARGV[2];}
else{$addon="";}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="$AnalyRootDir/$species";

# get the latest directory of updates for this species...
$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");
chdir("$outputdir/$subdir/$mydir");

open(SEQ,$addon."promoters.seq");
open(OUT,"> ".$addon."promoters.rpts");

$count=0;
$regexp="(([AGCT]{8,20})([AGCT]{0,200}?)\\2)";

$debug=1;
$done=0;
$line=<SEQ>;

#print "Output from program findRpts.pl for file: $ARGV[0])\n";
while (! $done) {
    &readSeq();
    $seq=~s/\s//g;
    $seq=~tr/a-z/A-Z/;
    $seqtitle=~/>(\S+)/;
    $name=$1;
    #print "\nAnalyzing sequence $name (",length($seq)," bp):\n";
    $count++;
    &maskSeq();
}
#print "Read $count sequences.\n";
close(SEQ);
close(OUT);
print "done finding rpts\n";
$a=qx+ls -al+;
print $a;

exit 0;

# -----------------------------------------------------------------------
sub readSeq() {
# Read until the next '>' character. Convert sequence to upper case.
    $seqtitle=$line;
    $seqtitle=~/^>(\S+)/;
    $genename=$1;
    $seq="";
    while ($line=<SEQ>) {
	if ($line=~/^>/) {
            return;
        }
	$seq.=$line;
    }
    $done=1;
    return;
}
# -----------------------------------------------------------------------
sub maskSeq() {
# find first match, then mask out all remaining matches from further scans...
    while($seq=~/$regexp/ig) {
       $seq2=$seq;
       $gap=$1;
       $flag=$2;
       $pos="";
       $curpos=pos($seq)-length($gap);
       while($seq2=~/$flag/ig) {
	   $pos.=(pos($seq2)-length($flag)-1500).",";
# add the masking here...
	   if(length($pos)>240) {
	       $pos.="...,";
	       last;
	   }
       }
       chop($pos);
       print OUT "$genename\t",$curpos-1500,"\t$flag {",length($3),"} $flag\t$pos\n";
       pos($seq)=$curpos+length($flag);  
    }
    return;
}


