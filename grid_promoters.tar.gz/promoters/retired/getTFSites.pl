#!/usr/bin/perl
# =====================================================
# Script to find TFSites in an input file of sequences.
# In this form, the consensus type sites are located. 
# =====================================================

if (! $ENV{ScriptHome}) {$ENV{ScriptHome}="/bioinfoA/db_updates/ncbi_genomes";}

$offset=-1500;

if($ARGV[0] eq "") {
    print "USAGE: getTFSites.pl <species> <FLDR> <type>\n";
    exit(1);
}
if($ARGV[2] eq "x" || $ARGV[2] eq "m") {$addon=$ARGV[2];}
else{$addon="";}

require("$ENV{ScriptHome}/lookups.pl");
$species=$ARGV[0];

# set up some defaults...
$dwnlddir="$DwnldRootDir/$species";
$outputdir="$AnalyRootDir/$species";
$scriptdir="$ENV{ScriptHome}/computes";

# get the latest directory of updates for this species...
$mydir="promoters";
require("$ENV{ScriptHome}/checkDir.pl");
chdir("$outputdir/$subdir/$mydir");

open(IN,$addon."promoters.seq");
open(OUT,"> ".$addon."promoters.tfsites");

$sitefile="/bioinfoA/db_updates/ncbi_genomes/promoters/tfsites/tfsites.dat";

%basecodes=("A","A",
	    "B","[TCG]",
	    "C","C",
	    "D","[AGT]",
	    "G","G",
	    "H","[ACT]",
	    "K","[GT]",
	    "M","[AC]",
	    "N","[AGCT]",
	    "R","[AG]",
	    "S","[CG]",
	    "T","T",
	    "U","T",
	    "V","[ACG]",
	    "W","[AT]",
	    "X","[AGCT]",
	    "Y","[CT]"); 

open(SITES,$sitefile);
$c=0;
while($line=<SITES>) {
  chop($line);
  ($name[$c],$site[$c])=split(/\t/,$line);
  $site[$c]=~tr/[a-z]/[A-Z]/;
  $reg[$c]="";
  for ($i=0;$i<length($site[$c]);$i++) {$reg[$c].=$basecodes{substr($site[$c],$i,1)};}
  $compreg=$reg[$c];
  $compreg=~tr/ACGT/TGCA/;
  $creg[$c]="";
  for($o=length($compreg);$o>=0;$o--) {$creg[$c].=substr($compreg,$o,1);} 
  $creg[$c]=~tr/[]/][/;
  $c++;
}
close(SITES);
#print "read $c sites in.\n";

#print "getTFSites.pl for $ARGV[0].\n";
$count=0;
while($line=<IN>) {
    chop($line);
    if($line=~/^>(\S+)/) {
	if($seq) {
	    #print substr($seq,1,10),"\n";
	    &mapper();
	    $seq="";
	    $count++;
	    #if($count%100==0) {print "$count\n";}
	}
	$seqid=$1;
	#print "=== $seqid ===";
    }
    else {$seq.=$line;}
}
if($seq) {
    &mapper($seq);
    $seq="";
    $count++;
}
close(IN);
close(OUT);

#print "Processed $count sequences.\n";
print "done processing tfsites\n";
$a=qx+ls -al+;
print $a;

exit 0;

sub mapper() { 
    $seq=~tr/a-z/A-Z/;
    $seq=~s/\s//g;
    $set="";
    for($n=0;$n<$c;$n++) {
	$hits="";
	$hc=0;
## uncomment here for full runs...
	while($seq=~m/$reg[$n]/g){
	    $hits.=pos($seq)-length($site[$n])+$offset.",";
            #print "$site[$n] $reg[$n] ",substr($seq,pos($seq)-length($site[$n]),length($site[$n])),"\n";
	    $hc++;
            if(length($hits)>240) {
		$hits.="...,";
		last;
	    }
	}
	if ($hits ne "") {
	    chop($hits);
	    $set.="$seqid\t$name[$n]\t$hc\t$hits\n";
	}
        $hits="";
        $hc=0;
	while($seq=~m/$creg[$n]/g){
	    $hits.=pos($seq)-length($site[$n])+$offset.",";
            #print "$site[$n] $creg[$n] ",substr($seq,pos($seq)-length($site[$n]),length($site[$n])),"\n";
	    $hc++;
            if(length($hits)>240) {
		$hits.="...,";
		last;
	    }
	}
	if ($hits ne "") {
	    chop($hits);
	    $set.="$seqid\t$name[$n]!\t$hc\t$hits\n";
	}
    }
    print OUT $set;
    return;
}
